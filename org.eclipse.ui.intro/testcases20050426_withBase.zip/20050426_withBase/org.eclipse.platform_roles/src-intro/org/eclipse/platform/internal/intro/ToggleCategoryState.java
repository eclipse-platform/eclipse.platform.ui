package org.eclipse.platform.internal.intro;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.activities.IActivityManager;
import org.eclipse.ui.activities.ICategory;
import org.eclipse.ui.activities.ICategoryActivityBinding;
import org.eclipse.ui.activities.IWorkbenchActivitySupport;
import org.eclipse.ui.activities.NotDefinedException;
import org.eclipse.ui.intro.IIntroSite;
import org.eclipse.ui.intro.config.IIntroAction;


public class ToggleCategoryState implements IIntroAction {
    public static String CATEGORY_ID_PARAM = "categoryId";

    // initialized on a run.
    private IWorkbenchActivitySupport workbenchActivitySupport = PlatformUI
        .getWorkbench().getActivitySupport();
    private IActivityManager activityManager = workbenchActivitySupport
        .getActivityManager();

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.config.IIntroAction#run(org.eclipse.ui.intro.IIntroSite,
     *           java.util.Properties)
     */
    public void run(IIntroSite site, Properties params) {
        String categoryId = params.getProperty(CATEGORY_ID_PARAM);

        // Get the category that needs to be toggled.
        ICategory category = activityManager.getCategory(categoryId);
        if (category == null)
            return;

        CategoryPresentation categoryPresentation = CategoryManager.getInst()
            .getCategoryPresentation(categoryId);
        String state = categoryPresentation.getCategoryState();

        if (state.equals(CategoryPresentation.STATE_ENABLED_LOCKED)) {
            // if category is locked, no-op return;
            MessageDialog.openInformation(site.getShell(), WelcomePlugin
                .getString("category_dialog.title"), "Locked category");
        }

        if (state.equals(CategoryPresentation.STATE_ENABLED_IMPLICITDISABLE)) {
            handleCategoryDisablement(site, category);
            return;
        }

        if (state.equals(CategoryPresentation.STATE_ENABLED)) {
            // if the category is currently enabled, disable all activities
            // associated with this category. Use category manager to check the
            // state of the
            disableAllActivities(category);
        }

        if (state.equals(CategoryPresentation.STATE_DISABLED)) {
            // Otherwise, the category is disabled. Enable all activities
            // associated with this category.
            enableCategory(category);
        }
    }


    private void handleCategoryDisablement(IIntroSite site, ICategory category) {
        String message = createCategoryMessage(category);
        boolean disableImplicitCatergories = MessageDialog.openQuestion(site
            .getShell(), WelcomePlugin.getString("category_dialog.title"),
            message);
        if (disableImplicitCatergories)
            disableAllActivities(category);
        else
            // INTRO: check code.
            disableSelectedCategory(category);
        return;
    }


    private String createCategoryMessage(ICategory category) {
        String message = "";
        // Get all the affected categories. For each category, get all
        // activities and remove them from the list of activities that needs to
        // be removed.
        Hashtable implicitlyDisabledCategoriesMap = CategoryManager.getInst()
            .getImplicitlyDisabledCategoriesMap();

        Set implicitlyDisabledCategories = (Set) implicitlyDisabledCategoriesMap
            .get(category.getId());
        Iterator it = implicitlyDisabledCategories.iterator();
        while (it.hasNext()) {
            String categoryId = (String) it.next();
            // INTRO:
            CategoryPresentation aCategoryPresentation = CategoryManager
                .getInst().getCategoryPresentation(categoryId);
            if (aCategoryPresentation.isCategoryEnabled())
                message = message + aCategoryPresentation.getCategoryName()
                        + "\n";
        }

        String categoryName = null;
        try {
            categoryName = category.getName();
        } catch (NotDefinedException e) {
            categoryName = "";
        }

        message = WelcomePlugin.getFormattedString("category_dialog.message",
            new Object[] { categoryName, message });
        return message;
    }


    /**
     * Disables all activities that belong to this category. It disables
     * activities that are required by activities being disabled here. Rational:
     * if a category is disabled, ALL its activities must be disabled, otherwise
     * some required activities will never be disabled.
     * 
     * @param category
     */
    private void disableAllActivities(ICategory category) {
        // disable all activities in this category.
        Set enabledIds = new HashSet(activityManager.getEnabledActivityIds());

        CategoryPresentation categoryPresentation = CategoryManager.getInst()
            .getCategoryPresentation(category.getId());
        disableCategoryActivities(enabledIds, categoryPresentation);

        // now disable all activities in implicitly disabled categories.
        Hashtable implicitlyDisabledCategoriesMap = CategoryManager.getInst()
            .getImplicitlyDisabledCategoriesMap();
        if (implicitlyDisabledCategoriesMap.containsKey(category.getId())) {
            Set implicitlyDisabledCategories = (Set) implicitlyDisabledCategoriesMap
                .get(category.getId());
            Iterator it = implicitlyDisabledCategories.iterator();
            while (it.hasNext()) {
                String categoryId = (String) it.next();
                CategoryPresentation aCategoryPresentation = CategoryManager
                    .getInst().getCategoryPresentation(categoryId);
                disableCategoryActivities(enabledIds, aCategoryPresentation);
            }
        }

        // update the current set of enabled activities.
        workbenchActivitySupport.setEnabledActivityIds(enabledIds);
    }


    private void disableCategoryActivities(Set enabledIds,
            CategoryPresentation categoryPresentation) {
        Set allActivities = categoryPresentation.getAllActivities();
        enabledIds.remove(allActivities);
    }



    /**
     * INTRO: really do this ...
     * 
     * @param category
     */
    private void disableSelectedCategory(ICategory category) {
        Set enabledIds = new HashSet(activityManager.getEnabledActivityIds());

        CategoryPresentation categoryPresentation = CategoryManager.getInst()
            .getCategoryPresentation(category.getId());
        Set activitiesToRemove = categoryPresentation.getAllActivities();

        // Get all the affected categories. For each category, get all
        // activities and remove them from the list of activities that needs to
        // be removed.
        Hashtable implicitlyDisabledCategoriesMap = CategoryManager.getInst()
            .getImplicitlyDisabledCategoriesMap();
        Set implicitlyDisabledCategories = (Set) implicitlyDisabledCategoriesMap
            .get(category.getId());
        for (int i = 0; i < implicitlyDisabledCategories.size(); i++) {
            // CategoryPresentation aCategoryPresentation =
            // (CategoryPresentation) CategoryManager
            // .getInst().getAvailableCategories().get(
            // implicitlyDisabledCategories.elementAt(i));
            // if (!aCategoryPresentation.isCategoryEnabled())
            // if the affected category is not enabled, nothing to do.
            // continue;
            // Vector aActivities = aCategoryPresentation.getAllActivities();
            // for (int j = 0; j < aActivities.size(); j++)
            // activitiesToRemove.remove(aActivities.elementAt(j));
        }

        // now remove the remaining activities.
        // for (int i = 0; i < activitiesToRemove.size(); i++)
        // enabledIds.remove(activitiesToRemove.elementAt(i));

        // update the current set of enabled activities
        // workbenchActivitySupport.setEnabledActivityIds(enabledIds);
    }



    private void enableCategory(ICategory category) {
        Set enabledIds = new HashSet(activityManager.getEnabledActivityIds());
        // enable all activities in this category. Enabling an activity
        // enables all required activities by this api call.
        Set activities = category.getCategoryActivityBindings();
        for (Iterator it = activities.iterator(); it.hasNext();) {
            ICategoryActivityBinding binding = (ICategoryActivityBinding) it
                .next();
            if (!enabledIds.contains(binding.getActivityId())) {
                enabledIds.add(binding.getActivityId());
            }
        }
        // update the current set of enabled activities
        workbenchActivitySupport.setEnabledActivityIds(enabledIds);
    }



}
