/*******************************************************************************
 * Copyright (c) 2004, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.platform.internal.intro;

import java.util.*;

import org.eclipse.ui.*;
import org.eclipse.ui.actions.*;
import org.eclipse.ui.intro.*;
import org.eclipse.ui.intro.config.*;

/**
 * An Intro Action that runs an action with the passed "actionId". The action is
 * constructed from UI factory class, when possible.
 *  
 */
public class RunActionFromId implements IIntroAction {

    public void run(IIntroSite site, Properties params) {
        final String actionID = params.getProperty("actionId"); //$NON-NLS-1$
        if (actionID != null) {
            try {
                // Get the correct action factory and create an action in the
                // active workbench window
                IWorkbench wb = PlatformUI.getWorkbench();
                IWorkbenchWindow window = wb.getActiveWorkbenchWindow();
                ActionFactory.IWorkbenchAction action = null;
                if (actionID.equals("preferences")) //$NON-NLS-1$
                    action = ActionFactory.PREFERENCES.create(window);

                else if (actionID.equals("import")) { //$NON-NLS-1$
                    action = ActionFactory.IMPORT.create(window);

                    // INTRO: launch import wiard directly. Use
                    // createExcutableExtension trick.
                    /*
                     * IImportWizard wizard = new PreferencesImportWizard();
                     * wizard.init(wb, new StructuredSelection()); WizardDialog
                     * dialog = new WizardDialog(window.getShell(), wizard);
                     * dialog.open();
                     */

                } else if (actionID.equals("export")) //$NON-NLS-1$
                    action = ActionFactory.EXPORT.create(window);

                if (action != null) {
                    action.run();
                    action.dispose();
                }

            } catch (Exception e) {
                Util.logError("Failed to run platform Intro action: " //$NON-NLS-1$
                        + actionID, e);
            }
        }
    }

}