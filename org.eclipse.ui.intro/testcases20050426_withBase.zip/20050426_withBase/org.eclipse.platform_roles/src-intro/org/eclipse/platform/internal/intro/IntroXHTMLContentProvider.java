/*******************************************************************************
 * Copyright (c) 2004, 2005 IBM Corporation and others. All rights reserved.
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/

package org.eclipse.platform.internal.intro;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.activities.ActivityManagerEvent;
import org.eclipse.ui.activities.IActivityManager;
import org.eclipse.ui.activities.IActivityManagerListener;
import org.eclipse.ui.activities.ICategory;
import org.eclipse.ui.activities.IWorkbenchActivitySupport;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ImageHyperlink;
import org.eclipse.ui.intro.config.IIntroContentProviderSite;
import org.eclipse.ui.intro.config.IIntroXHTMLContentProvider;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class IntroXHTMLContentProvider implements IIntroXHTMLContentProvider,
        IActivityManagerListener {



    // image location format depends on the dynamic content being produced.
    private static String ENABLED_ICON_LOCATION_HTML = "../graphics/icons/obj48/checkbox.gif";
    private static String DISABLED_ICON_LOCATION_HTML = "../graphics/icons/obj48/checkboxoff.gif";
    private static String ENABLED_ICON_LOCATION_SWT = "css/graphics/icons/obj48/checkbox.gif";
    private static String DISABLED_ICON_LOCATION_SWT = "css/graphics/icons/obj48/checkboxoff.gif";

    protected IActivityManager activityManager;
    private IIntroContentProviderSite contentProviderSite;

    public void init(IIntroContentProviderSite site) {
        IWorkbenchActivitySupport workbenchActivitySupport = PlatformUI
            .getWorkbench().getActivitySupport();
        activityManager = workbenchActivitySupport.getActivityManager();
        activityManager.addActivityManagerListener(this);
        this.contentProviderSite = site;
    }

    public void activityManagerChanged(ActivityManagerEvent activityManagerEvent) {
        contentProviderSite.reflow(this, false);
    }

    public void createContent(String id, PrintWriter out) {
        // do nothing since we are using XHTML support
    }

    public void createContent(String id, Composite parent, FormToolkit toolkit) {
        Set categoryIds = activityManager.getDefinedCategoryIds();
        Iterator it = categoryIds.iterator();
        while (it.hasNext()) {
            // create each category
            String categoryId = (String) it.next();
            ICategory category = activityManager.getCategory(categoryId);
            String state = CategoryManager.getInst().getCategoryPresentation(
                categoryId).getCategoryState();
            createSWTCategory(category, parent, toolkit, state);
        }
    }

    /**
     * For each category, create an image hyperlink and some text.
     */
    private void createSWTCategory(ICategory category, Composite parent,
            FormToolkit toolkit, String categoryState) {
        try {
            ImageHyperlink categoryLink = toolkit.createImageHyperlink(parent,
                SWT.BOTTOM);
            categoryLink.setText(category.getName());
            categoryLink.setToolTipText(categoryState);
            if (categoryState.equals(CategoryPresentation.STATE_ENABLED))
                categoryLink.setImage(Util.createPlatformImageDescriptor(
                    ENABLED_ICON_LOCATION_SWT).createImage());
            else
                categoryLink.setImage(Util.createPlatformImageDescriptor(
                    DISABLED_ICON_LOCATION_SWT).createImage());
            Label label2 = toolkit.createLabel(parent, category
                .getDescription(), SWT.WRAP);
        } catch (Exception e) {
            Util.logError("Platform Intro failed to create image for: "
                    + category.getId(), e);
        }
    }



    /**
     * For every category, create a div that has the name and description.
     */
    public void createContent(String id, Element parent) {
        Set categoryIds = activityManager.getDefinedCategoryIds();
        Iterator it = categoryIds.iterator();
        while (it.hasNext()) {
            // create each category
            String categoryId = (String) it.next();
            ICategory category = activityManager.getCategory(categoryId);
            String state = CategoryManager.getInst().getCategoryPresentation(
                categoryId).getCategoryState();
            createXHTMLCategory(category, parent, state);
        }

    }


    /**
     * For each category, create the following XHTML: <br />
     * <div>
     * <h4 class="category">Category name <img border="0"
     * src="../graphics/icons/obj48/checkbox.gif" width="28" height="31"
     * alt="disabled" /></h4>
     * <p class="category-desc">
     * category description
     * </p>
     * </div>
     * 
     * The alt of the enabled/disabled image represents the state of the
     * category.
     * 
     */
    private void createXHTMLCategory(ICategory category, Element parent,
            String categoryState) {
        Document dom = parent.getOwnerDocument();
        Properties att = new Properties();
        att.setProperty("class", "category"); //$NON-NLS-1$ //$NON-NLS-2$
        Element h4 = Util.createChild(parent, "h4", att); //$NON-NLS-1$

        att.clear();
        if (categoryState.equals(CategoryPresentation.STATE_ENABLED))
            att.setProperty("src", ENABLED_ICON_LOCATION_HTML);
        else
            att.setProperty("src", DISABLED_ICON_LOCATION_HTML);
        att.setProperty("width", "28"); //$NON-NLS-1$ //$NON-NLS-2$
        att.setProperty("height", "31"); //$NON-NLS-1$ //$NON-NLS-2$
        att.setProperty("alt", categoryState); //$NON-NLS-1$
        Element name = Util.createChild(h4, "img", att); //$NON-NLS-1$

        att.clear();
        att.setProperty("class", "category-desc"); //$NON-NLS-1$ //$NON-NLS-2$
        Element descriptionP = Util.createChild(parent, "p", att); //$NON-NLS-1$
        try {
            h4.appendChild(dom.createTextNode(category.getName()));
            descriptionP.appendChild(dom.createTextNode(category
                .getDescription()));
        } catch (Exception e) {
            Util.logError(
                "Platform Intro failed to read attributes for category: " //$NON-NLS-1$
                        + category.getId(), e);
        }
    }

    private String createIntroURLAction(String categoryId) {
        StringBuffer url = new StringBuffer(
            "http://org.eclipse.ui.intro/runAction?pluginId=org.eclipse.platform&amp;class=org.eclipse.platform.internal.intro.ToggleCategoryState&amp;");
        return url.append(ToggleCategoryState.CATEGORY_ID_PARAM).append("=")
            .append(categoryId).toString();
    }


    public void dispose() {
        // make sure to cleanup.
        activityManager.removeActivityManagerListener(this);

    }
}