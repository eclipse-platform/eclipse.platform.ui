package org.eclipse.platform.internal.intro;

import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.ui.internal.intro.impl.util.Log;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;


public class WelcomePlugin extends AbstractUIPlugin {
    // The template resource bundle.
    public static String WELCOME_BUNDLE = "org.eclipse.platform"; //$NON-NLS-1$
    public static String WELCOME_RESOURCE_BUNDLE = "org.eclipse.platform.resources"; //$NON-NLS-1$

    // There should always be a single instance of all these classes.
    private ResourceBundle welcomeBundle;

    // The static shared instance.
    private static WelcomePlugin inst;

    // Hashtable where key is the categoryId and value id the resolved category
    // icon path.
    Hashtable categoryIcons = new Hashtable();

    /**
     * The constructor.
     */
    public WelcomePlugin() {
        super();
    }


    /**
     * Returns the shared plugin instance.
     */
    public static WelcomePlugin getDefault() {
        return inst;
    }

    /**
     * Returns the string from the plugin's resource bundle, or 'key' if not
     * found.
     */
    public static String getString(String key) {
        try {
            ResourceBundle bundle = WelcomePlugin.getDefault()
                .getResourceBundle();
            return (bundle != null ? bundle.getString(key) : key);
        } catch (MissingResourceException e) {
            // ok to return Key.
            return key;
        }
    }

    /**
     * Utility method to get a resource from the given key, then format it with
     * the given substitutions. <br>
     */
    public static String getFormattedString(String key, Object[] args) {
        return MessageFormat.format(getString(key), args);
    }

    /**
     * Returns the plugin's resource bundle.
     */
    public ResourceBundle getResourceBundle() {
        return welcomeBundle;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
     */
    public void start(BundleContext context) throws Exception {
        super.start(context);
        inst = this;
        try {
            welcomeBundle = ResourceBundle.getBundle(WELCOME_RESOURCE_BUNDLE);
        } catch (MissingResourceException x) {
            welcomeBundle = null;
            Log.warning("WelcomePlugin - unable to load resource bundle"); //$NON-NLS-1$
        }
    }


    /*
     * (non-Javadoc)
     * 
     * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
     */
    public void stop(BundleContext context) throws Exception {
        super.stop(context);
    }



}