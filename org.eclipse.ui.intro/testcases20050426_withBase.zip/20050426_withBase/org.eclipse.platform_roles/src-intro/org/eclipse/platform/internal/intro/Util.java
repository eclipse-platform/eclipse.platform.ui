/*******************************************************************************
 * Copyright (c) 2004, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.platform.internal.intro;

import java.net.*;
import java.util.*;

import org.eclipse.core.runtime.*;
import org.eclipse.jface.resource.*;
import org.eclipse.ui.internal.intro.impl.util.*;
import org.osgi.framework.*;
import org.w3c.dom.*;

/**
 * Util class to manipulate XHTML DOM, and create dynamic content.
 */
public class Util {

    private static final String PLATFORM_PLUGIN_ID = "org.eclipse.platform"; //$NON-NLS-1$

    public static Element createElement(Document dom, String elementName,
            Properties attributes) {

        Element element = dom.createElement(elementName);
        if (attributes != null) {
            Enumeration e = attributes.keys();
            while (e.hasMoreElements()) {
                String key = (String) e.nextElement();
                element.setAttribute(key, attributes.getProperty(key));
            }
        }
        return element;
    }

    public static Element createChild(Element parentElement,
            String elementName, Properties attributes) {

        Element element = createElement(parentElement.getOwnerDocument(),
            elementName, attributes);
        parentElement.appendChild(element);
        return element;
    }

    public static void logError(String message, Exception e) {
        Bundle bundle = Platform.getBundle(PLATFORM_PLUGIN_ID);
        ILog platformLog = Platform.getLog(bundle);
        Status errorStatus = new Status(IStatus.ERROR, PLATFORM_PLUGIN_ID,
            IStatus.OK, message, e);
        platformLog.log(errorStatus);
    }


    public static ImageDescriptor createImageDescriptor(Bundle bundle,
            String imageName) {
        try {
            URL imageUrl = Platform.find(bundle, new Path(imageName));
            ImageDescriptor desc = ImageDescriptor.createFromURL(imageUrl);
            return desc;
        } catch (Exception e) {
            // Should never be here.
            Log.error("could not create Image Descriptor", e); //$NON-NLS-1$
            return ImageDescriptor.getMissingImageDescriptor();
        }
    }

    public static ImageDescriptor createPlatformImageDescriptor(String imageName) {
        Bundle platformBundle = Platform.getBundle(PLATFORM_PLUGIN_ID);
        return createImageDescriptor(platformBundle, imageName);
    }


}