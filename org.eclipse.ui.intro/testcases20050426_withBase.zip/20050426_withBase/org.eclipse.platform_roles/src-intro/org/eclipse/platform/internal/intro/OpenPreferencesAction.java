/*******************************************************************************
 * Copyright (c) 2004, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.platform.internal.intro;

import java.util.*;

import org.eclipse.jface.preference.*;
import org.eclipse.ui.*;
import org.eclipse.ui.dialogs.*;
import org.eclipse.ui.intro.*;
import org.eclipse.ui.intro.config.*;

/**
 * An Intro Action that opens the preference page on a given keyword id. Format
 * of the URL that uses this class is as follows:
 * http://org.eclipse.ui.intro/runAction? pluginId=org.eclipse.platform&amp;
 * class=org.eclipse.platform.intro.OpenPreferencesAction&amp;
 * preferenceKeywordId=org.eclipse.ui.ide.editing. <br />
 * The keywords are taken from any keyword that is defined in the workbench
 * using the keyword extension point.
 *  
 */
public class OpenPreferencesAction implements IIntroAction {

    public void run(IIntroSite site, Properties params) {
        // if keyword is null, load all preferences.
        final String preferenceKeywordId = params
            .getProperty("preferenceKeywordId"); //$NON-NLS-1$
        String pageToSelect = null;
        String[] pagesToSelect = null;

        if (preferenceKeywordId != null) {
            // General (Appearance key word).
            if (preferenceKeywordId.equals("org.eclipse.ui.ide.appearance")) { //$NON-NLS-1$
                pagesToSelect = new String[] {
                        "org.eclipse.ui.preferencePages.Workbench", //$NON-NLS-1$
                        "org.eclipse.ui.preferencePages.Perspectives", //$NON-NLS-1$
                        "org.eclipse.ui.preferencePages.Views", //$NON-NLS-1$
                        "org.eclipse.ui.preferencePages.ColorsAndFonts", //$NON-NLS-1$
                        "org.eclipse.ui.preferencePages.Decorators", //$NON-NLS-1$
                        "org.eclipse.jdt.ui.preferences.AppearancePreferencePage" }; //$NON-NLS-1$
                pageToSelect = "org.eclipse.ui.preferencePages.Views"; //$NON-NLS-1$

            } else if (preferenceKeywordId.equals("org.eclipse.ui.ide.editing")) { //$NON-NLS-1$
                // Editing keyword.
                pagesToSelect = new String[] {
                // from ui plugin.
                        " org.eclipse.ui.preferencePages.Editors", //$NON-NLS-1$
                        "org.eclipse.ui.preferencePages.FileEditors", //$NON-NLS-1$
                        "org.eclipse.ui.preferencePages.Keys", //$NON-NLS-1$
                        // from editors plugin
                        "org.eclipse.ui.preferencePages.GeneralTextEditor", //$NON-NLS-1$
                        "org.eclipse.ui.editors.preferencePages.Annotations", //$NON-NLS-1$
                        "org.eclipse.ui.editors.preferencePages.QuickDiff", //$NON-NLS-1$
                        "org.eclipse.ui.editors.preferencePages.Accessibility", //$NON-NLS-1$
                        "org.eclipse.ui.editors.preferencePages.Spelling" }; //$NON-NLS-1$
                pageToSelect = "org.eclipse.ui.preferencePages.Editors"; //$NON-NLS-1$

            } else if (preferenceKeywordId.equals("org.eclipse.jdt.ui")) { //$NON-NLS-1$
                // Java preferences. plugin id used only for now. Will use
                // keywords when they are used better.
                pagesToSelect = new String[] {
                        " org.eclipse.jdt.ui.preferences.JavaBasePreferencePage", //$NON-NLS-1$
                        "org.eclipse.jdt.ui.preferences.AppearancePreferencePage" }; //$NON-NLS-1$
                pageToSelect = "org.eclipse.jdt.ui.preferences.JavaBasePreferencePage"; //$NON-NLS-1$

            } else if (preferenceKeywordId.equals("org.eclipse.pde.ui")) { //$NON-NLS-1$
                // PDE preferences. plugin id used only for now. Will use
                // keywords when they are used better.
                pagesToSelect = new String[] {
                        "org.eclipse.pde.ui.MainPreferencePage", //$NON-NLS-1$
                        "org.eclipse.pde.ui.TargetPlatformPreferencePage", //$NON-NLS-1$
                        "org.eclipse.pde.ui.EditorPreferencePage", //$NON-NLS-1$
                        "org.eclipse.pde.ui.CompilersPreferencePage" }; //$NON-NLS-1$
                pageToSelect = "org.eclipse.pde.ui.MainPreferencePage"; //$NON-NLS-1$
            }
        }

        // Now open the preferences ...
        IWorkbench wb = PlatformUI.getWorkbench();
        PreferenceDialog dialog = PreferencesUtil.createPreferenceDialogOn(
            null, pageToSelect, pagesToSelect, null);
        dialog.open();



    }

}