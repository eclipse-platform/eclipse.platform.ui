package org.eclipse.platform.internal.intro;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.activities.IActivityManager;
import org.eclipse.ui.activities.ICategory;
import org.eclipse.ui.activities.IMutableActivityManager;
import org.eclipse.ui.activities.WorkbenchActivityHelper;


public class CategoryManager {

    protected IActivityManager activityManager;

    // Keys are category id. Values are CategoryPresentation.
    private Hashtable availableCategories;
    // set of all defined category ids.
    private Set categoryIds;

    // Keys are category id. Values are a Set of category ids that can be
    // implicitly enabled by the category key. A category is implicitly enabled
    // by another category if all its activities and required activities can be
    // enabled by the first category.
    private Hashtable implicitlyEnabledCategoriesMap;

    // same as above, but with a mutableActivityManager where all categories are
    // turned off.
    private Hashtable all_ImplicitlyEnabledCategories = new Hashtable();

    // Keys are category id. Values are a Set of category ids that can be
    // implicitly disabled by the category key.
    private Hashtable implicitlyDisabledCategoriesMap;

    private static CategoryManager inst = new CategoryManager();


    private CategoryManager() {
        this.activityManager = PlatformUI.getWorkbench().getActivitySupport()
            .getActivityManager();
        this.categoryIds = activityManager.getDefinedCategoryIds();
        // loads all categories and checks which are enabled. Has to be recalled
        // every time we regen the page.
        this.availableCategories = createCategoryPresentations();
        implicitlyEnabledCategoriesMap = computeImplicitlyEnabledCategories();
        implicitlyDisabledCategoriesMap = computeImplicitlyDisabledCategories();
        all_ImplicitlyEnabledCategories = computeAll_ImplicitlyEnabledCategories();
    }



    public static CategoryManager getInst() {
        return inst;
    }

    /**
     * Create a collection of all available categories
     */
    private Hashtable createCategoryPresentations() {
        Hashtable availableCategories = new Hashtable();
        Set categoryIds = activityManager.getDefinedCategoryIds();
        for (Iterator it = categoryIds.iterator(); it.hasNext();) {
            String id = (String) it.next();
            ICategory category = activityManager.getCategory(id);
            CategoryPresentation presentation = new CategoryPresentation(
                activityManager, category);
            availableCategories.put(id, presentation);
        }
        return availableCategories;
    }



    public Hashtable getImplicitlyEnabledCategoriesMap() {
        return implicitlyEnabledCategoriesMap;
    }

    public Hashtable getImplicitlyDisabledCategoriesMap() {
        return implicitlyDisabledCategoriesMap;
    }


    /**
     * Create the hashtable of all categories that can be implicitly enabled.
     */
    public Hashtable computeImplicitlyEnabledCategories() {
        return doComputeImplicitlyEnabledCategories(activityManager);
    }

    /**
     * Create the hashtable of all categories that can be implicitly enabled.
     */
    private Hashtable doComputeImplicitlyEnabledCategories(
            IActivityManager anActivityManager) {

        Hashtable implicitlyEnabledCategories = new Hashtable();
        for (Iterator it = categoryIds.iterator(); it.hasNext();) {
            // for every category, get all categories that can be enabled if
            // this category is enabled. Only add to hastable categories that do
            // indeed enabled other categories.
            String currentCategoryId = (String) it.next();
            Set enabledCategoryIds = WorkbenchActivityHelper
                .getEnabledCategories(anActivityManager, currentCategoryId);
            if (enabledCategoryIds != null && enabledCategoryIds.size() > 0)
                implicitlyEnabledCategories.put(currentCategoryId,
                    enabledCategoryIds);
        }
        return implicitlyEnabledCategories;
    }

    /**
     * Create the hashtable of all categories that can be implicitly enabled.
     */
    public Hashtable computeAll_ImplicitlyEnabledCategories() {
        // vector that will hold mapping of a category and the categories it
        // enables.
        IMutableActivityManager mutableActivityManager = PlatformUI
            .getWorkbench().getActivitySupport().createWorkingCopy();
        mutableActivityManager.setEnabledActivityIds(Collections.EMPTY_SET);
        return doComputeImplicitlyEnabledCategories(mutableActivityManager);
    }




    /**
     * Create the hashtable of all categories that can be implicitly disabled.
     */
    public Hashtable computeImplicitlyDisabledCategories() {

        Hashtable implicitlyDisabledCategories = new Hashtable();
        for (Iterator it = categoryIds.iterator(); it.hasNext();) {
            // for every category, get all categories that can be enabled if
            // this category is enabled. Only add to hastable categories that do
            // indeed enabled other categories.
            String currentCategoryId = (String) it.next();
            Set disabledCategoryIds = WorkbenchActivityHelper
                .getDisabledCategories(activityManager, currentCategoryId);
            if (disabledCategoryIds != null && disabledCategoryIds.size() > 0)
                implicitlyDisabledCategories.put(categoryIds,
                    disabledCategoryIds);
        }
        return implicitlyDisabledCategories;
    }



    public boolean categoryCanImplicitDisable(String categoryId) {
        return implicitlyDisabledCategoriesMap.containsKey(categoryId);
    }

    public boolean categoryIsParent(String categoryId) {
        return implicitlyEnabledCategoriesMap.containsKey(categoryId);
    }

    public CategoryPresentation getCategoryPresentation(String categoryId) {
        return (CategoryPresentation) availableCategories.get(categoryId);
    }


    public boolean categoryIsLocked(String categoryId) {
        boolean categoryIsLocked = false;
        CategoryPresentation categoryPresentation = getCategoryPresentation(categoryId);
        if (!categoryPresentation.isCategoryEnabled())
            // if category is not enabled, it can not be locked.
            return false;

        for (Enumeration en = all_ImplicitlyEnabledCategories.keys(); en
            .hasMoreElements();) {

            String key = (String) en.nextElement();
            Set implicitEnabledCategoriesSet = (Set) all_ImplicitlyEnabledCategories
                .get(key);
            Vector implicitEnabledCategories = new Vector(
                implicitEnabledCategoriesSet);

            if (implicitEnabledCategories.contains(categoryId)) {
                // param categoryId can be implicitly enabled by another
                // category. find out which category can enable it, and
                // if that category is enabled, then categoryId category is
                // locked.
                CategoryPresentation presentation = (CategoryPresentation) availableCategories
                    .get(key);
                if (presentation.isCategoryEnabled()) {
                    // we have an enabled parent category for the current
                    // category.This means that the current category is
                    // locked.
                    categoryIsLocked = true;
                    break;
                }
            }
        }
        return categoryIsLocked;
    }



    /*
     * Update the enablement state of the categories. For performance, this
     * should be the only thing to be re-computed.
     */
    public void activityManagerChanged() {
        for (Enumeration en = availableCategories.elements(); en
            .hasMoreElements();) {
            CategoryPresentation presentation = (CategoryPresentation) en
                .nextElement();
            presentation.updateEnabledState();
        }
    }
}
