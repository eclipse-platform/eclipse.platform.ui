package org.eclipse.ui.tests.intro.impl;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.eclipse.ui.tests.intro.impl.performance.SDKIntroPerfTest;

public class AllIntroTests {

    public static Test suite() {
        TestSuite suite = new TestSuite(
            "Test for org.eclipse.ui.tests.intro.impl");
        // $JUnit-BEGIN$
        suite.addTestSuite(SDKIntroTest.class);
        suite.addTestSuite(SDKIntroPerfTest.class);
        // $JUnit-END$
        return suite;
    }

}
