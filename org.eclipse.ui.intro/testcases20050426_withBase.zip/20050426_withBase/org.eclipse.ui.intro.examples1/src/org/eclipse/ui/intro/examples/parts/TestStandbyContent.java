/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Common Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/
package org.eclipse.ui.intro.examples.parts;

import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.*;
import org.eclipse.ui.forms.widgets.*;
import org.eclipse.ui.intro.*;
import org.eclipse.ui.intro.config.*;



public class TestStandbyContent implements IStandbyContentPart {

    Composite composite;

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.intro.impl.parts.IStandbyContentPart#createControl(org.eclipse.swt.widgets.Composite,
     *      org.eclipse.ui.forms.widgets.FormToolkit)
     */
    public void createPartControl(Composite parent, FormToolkit toolkit) {
        composite = toolkit.createComposite(parent);
        composite.setLayout(new GridLayout());
        Button button = toolkit.createButton(composite, "hi", SWT.NULL);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.intro.impl.parts.IStandbyContentPart#getControl()
     */
    public Control getControl() {
        return composite;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.intro.impl.parts.IStandbyContentPart#init(org.eclipse.ui.intro.IIntroPart)
     */
    public void init(IIntroPart introPart, IMemento memento) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.intro.impl.parts.IStandbyContentPart#setInput(java.lang.Object)
     */
    public void setInput(Object input) {
        System.out.println("setInput");

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.intro.impl.parts.IStandbyContentPart#setFocus()
     */
    public void setFocus() {
        System.out.println("setFocus");

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.intro.impl.parts.IStandbyContentPart#dispose()
     */
    public void dispose() {
        System.out.println("dispose");

    }

    public void saveState(IMemento memento) {
    }

}