/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.ui.intro.examples.parts;

import java.util.*;

import org.eclipse.ui.*;
import org.eclipse.ui.intro.*;
import org.eclipse.ui.intro.config.*;

/**
 * A default Intro Action that opens a perspective given an id.
 */
public class OpenPerspectiveAction implements IIntroAction {


    /*public void run(IIntroSite site, Properties params) {
        try {
            // get the id of the perspective to open.
            String id = params.getProperty("perspectiveId", "");
            if (id.equals(""))
                // quick exit
                return;
            //IntroPlugin.closeIntro();
            PlatformUI.getWorkbench().openWorkbenchWindow(id, null);
            //IntroPlugin.showIntro(true);

        } catch (Exception ex) {
            // REVISIT:
            System.out.println("Could not run intro action.");
            System.out.println(ex);
        }
    }
    */
    
    public void run(IIntroSite site, Properties params) {
		final String perspectiveID = params.getProperty("perspectiveId");
		if (perspectiveID != null) {
			try {
				// Close the intro view ...
			    IIntroPart introPart = PlatformUI.getWorkbench().getIntroManager()
                .getIntro(); 
			    PlatformUI.getWorkbench().getIntroManager().closeIntro(introPart);

				// Open the perspective ...
				IWorkbench wb = PlatformUI.getWorkbench();
				wb.showPerspective(perspectiveID, wb.getActiveWorkbenchWindow());
			} catch (Exception e) { // log err }
		}
	}
}

    

}