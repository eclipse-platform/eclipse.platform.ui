// General purpose functions. 

function hide_element(elementId) {
	element = document.getElementById(elementId);
	if(element != null) {
		currentClass = element.className;
		if(currentClass == 'toggle-on') {
			element.className = 'toggle-off';
		}
	}
}

function show_element(elementId) {
	element = document.getElementById(elementId);
	if(element != null) {
		currentClass = element.className;
		if(currentClass == 'toggle-off') {
			element.className = 'toggle-on';
		}
	}
}

function toggle_element_class(elementId) {
	element = document.getElementById(elementId);
	if(element != null) {
		currentClass = element.className;
		if(currentClass == 'toggle-on') {
			element.className = 'toggle-off';
		}
		else if(currentClass == 'toggle-off') {
			element.className = 'toggle-on';
		}
	}
}

function switch_image_src(imageId, newSrc) {
	imageElement = document.getElementById(imageId);
	if(imageElement != null) {
		imageElement.setAttribute('src', newSrc);
	}
}

function show_text(elementId, text) {
	element = document.getElementById(elementId);
	if(element != null) {
		element.innerHTML=text;
	}
	
}

function show_multiple_text(elementId1, text1, elementId2, text2) {
	show_text(elementId1, text1);
	show_text(elementId2, text2);
}

function reset_text(elementId){
	show_text(elementId, ' ');
}


function toggle_role_guy(toggleElement, roleDesc) {
	hide_element(roleDesc);
	toggle_element_class(toggleElement);
}

function onMouseover_role_guy(roleGuyId, flyOutDivId) {
	flyOutDivElement = document.getElementById(flyOutDivId);
	if(flyOutDivElement != null) {
		currentClass = flyOutDivElement.className;
		if(currentClass == 'toggle-off') 
			show_element(roleGuyId);
	}
}

/* 
This function is used by the enabled categories to toggle the flyout. It is 
needed since cliking on the actual category link is a no-op. Needed for 
accessibility.
*/
function onKeyPress_toggle_role_guy(toggleElement, roleDesc) {
	toggle_role_guy(toggleElement, roleDesc);
}


function handle_category_mouseover(elementId1, text1, elementId2, text2, elementId3, text3, id) {
	show_multiple_text(elementId1, text1, elementId2, text2);
	show_element(elementId3);
	if(text3!="")
		show_text(elementId3, text3);
	
}


function highlightDependencies(id){
	element = document.getElementById(id);
	if(element != null) {
		str="border:1px black solid";
		element.style.cssText = str;
	}
}


function handle_category_mouseout(elementId1, text1, elementId2, text2, elementId3) {
	show_multiple_text(elementId1, text1, elementId2, text2);
	reset_text(elementId3);
	hide_element(elementId3);
}
	
	
	
	




