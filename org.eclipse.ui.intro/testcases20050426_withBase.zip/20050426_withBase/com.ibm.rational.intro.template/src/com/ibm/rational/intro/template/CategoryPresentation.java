package com.ibm.rational.intro.template;

import java.util.*;

import org.eclipse.ui.activities.*;

/**
 * Represents cached information about an ICategory. Its a model class that can
 * be asked for activities/required activities that belong to the wrapped
 * category. <br>
 * Note: At this time, an icon can not be associated with a given category in
 * the xml markup, so this class is currently also responsible for assigning the
 * image to be displayed. This functionality should be revisited.
 */
public class CategoryPresentation {

    public static final String STATE_ENABLED = "enabled";
    public static final String STATE_ENABLED_IMPLICITDISABLE = "enabled-implicitDisable";
    public static final String STATE_ENABLED_LOCKED = "enabled-locked";
    public static final String STATE_DISABLED = "disabled";
    public static final String STATE_DISABLED_PARENT = "disabled-parent";

    private IActivityManager activityManager;
    private ICategory category;
    protected String iconPath;
    private boolean enabled;
    private String state;

    // this vector will hold all activities belonging to this category.
    private Vector activities;
    // this vector will hold all activities required by activities in this
    // category.
    private Vector requiredActivities;

    public CategoryPresentation(IActivityManager manager, ICategory category) {
        this.activityManager = manager;
        this.category = category;
        this.enabled = updateEnabledState();
        computeCategoryActivities();
        updateCategoryIconPath();
    }

    /**
     * Returns a vector of all activities that belong to this category. Required
     * activities are also recuresivly added to the list.
     * 
     * @param category
     * @return
     */
    private void computeCategoryActivities() {
        activities = new Vector();
        requiredActivities = new Vector();
        Set activityBindings = category.getCategoryActivityBindings();
        // make sure to add all first level activities first, and then compute
        // the required activities.
        for (Iterator it = activityBindings.iterator(); it.hasNext();) {
            ICategoryActivityBinding binding = (ICategoryActivityBinding) it
                    .next();
            String activityId = binding.getActivityId();
            if (!activities.contains(activityId))
                activities.add(activityId);
        }

        for (Iterator it = activityBindings.iterator(); it.hasNext();) {
            ICategoryActivityBinding binding = (ICategoryActivityBinding) it
                    .next();
            String activityId = binding.getActivityId();
            addRequiredActivities(activityId);
        }
    }



    /**
     * Add all the required activities of the passed activity to the vector. It
     * is a recursive process, and so required activities or required activities
     * are also added.
     */
    private void addRequiredActivities(String activityId) {
        IActivity activity = activityManager.getActivity(activityId);
        for (Iterator it = activity.getActivityRequirementBindings().iterator(); it
                .hasNext();) {
            IActivityRequirementBinding activityBinding = (IActivityRequirementBinding) it
                    .next();
            String requiredActivityid = activityBinding.getRequiredActivityId();
            if (!activities.contains(requiredActivityid)
                    && !requiredActivities.contains(requiredActivityid)) {
                requiredActivities.add(requiredActivityid);
                addRequiredActivities(requiredActivityid);
            }
        }
    }



    /**
     * Returns all activities of this category, including required activities.
     */
    public Vector getAllActivities() {
        Vector allActivities = new Vector();
        if (activities.size() > 0)
            allActivities.addAll(activities);
        if (requiredActivities.size() > 0)
            allActivities.addAll(requiredActivities);
        return allActivities;
    }

    /**
     * Returns all activities of this category, including required activities.
     */
    public Vector getRequiredActivities() {
        return requiredActivities;
    }

    /**
     * A category is enabled if all activities bound to the category are
     * enabled.
     * 
     * @return true if enabled, false otherwise
     */
    public boolean isCategoryEnabled() {
        return enabled;
    }

    public String getCategoryState() {
        // for performance, calculate state only once. This will be updated when
        // the contentProviderSite is updated through a reflow.
        if (state != null)
            return state;

        // we never computed state before.
        boolean categoryIsLocked = CategoriesContentProvider.categoryManager
                .categoryIsLocked(category.getId());

        boolean categoryIsParent = CategoriesContentProvider.categoryManager
                .categoryIsParent(category.getId());

        boolean categoryCanImplicitDisable = CategoriesContentProvider.categoryManager
                .categoryCanImplicitDisable(category.getId());

        /**
         * state values: <br>
         * ------------ <br>
         * enabled, enabled-locked, enabled-implicitDisable, disabled,
         * disabled-parent.
         */
        if (isCategoryEnabled()) {
            state = "enabled";
            if (categoryIsLocked)
                state = state + "-locked";
            else if (categoryCanImplicitDisable)
                state = state + "-implicitDisable";

        } else {
            state = "disabled";
            if (categoryIsParent)
                state = state + "-parent";
        }
        return state;
    }

    /**
     * Return the ICategory element that this CategoryPresentation represents
     * 
     * @return
     */
    public ICategory getCategory() {
        return category;
    }

    public String getCategoryName() {
        String name = "";
        try {
            name = category.getName();
        } catch (NotDefinedException e) {
        }
        return name;
    }

    public String getCategoryDescription() {
        String description = "";
        try {
            description = category.getDescription();
        } catch (NotDefinedException e) {
        }
        return description;
    }

    public String getCategoryId() {
        return category.getId();
    }

    /**
     * Determine if this category is enabled. A category is enabled if all of
     * the activities bound to the category are enabled. Make sure to clear
     * cached state.
     * 
     * @return true if this category is enabled, and false otherwise
     */
    public boolean updateEnabledState() {
        state = null;
        for (Iterator it = category.getCategoryActivityBindings().iterator(); it
                .hasNext();) {
            ICategoryActivityBinding binding = (ICategoryActivityBinding) it
                    .next();
            if (!(activityManager.getEnabledActivityIds().contains(binding
                    .getActivityId()))) {
                enabled = false;
                return false;
            }

        }
        enabled = true;
        return true;
    }

    /**
     * This method sets the image path for this category, based on the
     * category's ID. <br>
     * 
     * categories are assigned icons through an extension point defined in this
     * plugin.
     *  
     */
    protected void updateCategoryIconPath() {
        iconPath = TemplatePlugin.getDefault()
                .getCategoryIcon(category.getId());
    }



    /**
     * Return the
     * 
     * @return
     */
    public String getIconPath() {
        if (iconPath != null)
            return iconPath;
        else
            return "";
    }


}