package com.ibm.rational.intro.template;

import java.util.*;

import org.eclipse.jface.dialogs.*;
import org.eclipse.ui.*;
import org.eclipse.ui.activities.*;
import org.eclipse.ui.intro.*;
import org.eclipse.ui.intro.config.*;


public class CategoryStateChanged implements IIntroAction {
    public static String CATEGORY_ID_PARAM = "categoryId";

    // initialized on a run.
    private IWorkbenchActivitySupport workbenchActivitySupport = PlatformUI
            .getWorkbench().getActivitySupport();
    private IActivityManager activityManager = workbenchActivitySupport
            .getActivityManager();

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.config.IIntroAction#run(org.eclipse.ui.intro.IIntroSite,
     *      java.util.Properties)
     */
    public void run(IIntroSite site, Properties params) {
        String categoryId = params.getProperty(CATEGORY_ID_PARAM);
        workbenchActivitySupport = PlatformUI.getWorkbench()
                .getActivitySupport();
        activityManager = workbenchActivitySupport.getActivityManager();

        // Get the category that was changed
        ICategory category = activityManager.getCategory(categoryId);
        if (category == null)
            return;

        CategoryPresentation categoryPresentation = (CategoryPresentation) CategoriesContentProvider.categoryManager
                .getAvailableCategories().get(category.getId());
        String state = categoryPresentation.getCategoryState();

        if (state.equals(CategoryPresentation.STATE_ENABLED_LOCKED))
            // if category is locked, no-op
            return;


        if (state.equals(CategoryPresentation.STATE_ENABLED_IMPLICITDISABLE)) {
            handleCategoryDisablement(site, category);
            return;
        }

        if (state.equals(CategoryPresentation.STATE_ENABLED))
            // If the category is currently enabled, disable all activities
            // associated with this category. Use category manager to check the
            // state of the category.
            disableAllActivities(category);
        else
            // Otherwise, the category is disabled. Enable all activities
            // associated with this category.
            enableCategory(category);
    }


    private void handleCategoryDisablement(IIntroSite site, ICategory category) {
        String message = createCategoryMessage(category);

        boolean disableImplicitCatergories = MessageDialog.openQuestion(site
                .getShell(), TemplatePlugin.getString("category_dialog.title"),
                message);

        if (disableImplicitCatergories)
            disableAllActivities(category);
        else
            disableSelectedCategory(category);

        return;

    }


    private String createCategoryMessage(ICategory category) {
        String message = "";
        // Get all the affected categories. For each category, get all
        // activities and remove them from the list of activities that needs to
        // be removed.
        Hashtable implicitlyDisabledCategoriesMap = CategoriesContentProvider.categoryManager
                .getImplicitlyDisabledCategoriesMap();

        Vector implicitlyDisabledCategories = (Vector) implicitlyDisabledCategoriesMap
                .get(category.getId());
        for (int i = 0; i < implicitlyDisabledCategories.size(); i++) {
            CategoryPresentation aCategoryPresentation = (CategoryPresentation) CategoriesContentProvider.categoryManager
                    .getAvailableCategories().get(
                            implicitlyDisabledCategories.elementAt(i));
            if (aCategoryPresentation.isCategoryEnabled())
                message = message + aCategoryPresentation.getCategoryName()
                        + "\n";
        }

        String categoryName = null;
        try {
            categoryName = category.getName();
        } catch (NotDefinedException e) {
            categoryName = "";
        }

        message = TemplatePlugin.getFormattedString("category_dialog.message",
                new Object[] { categoryName, message });
        return message;
    }

    /**
     * Disables all activities that belong to this category. It disables
     * activities that are required by activities being disabled here. Rational:
     * if a category is disabled, ALL its activities must be disabled, otherwise
     * some required activities will never be disabled.
     * 
     * @param category
     */
    private void disableAllActivities(ICategory category) {
        // disable all activities in this category.
        Set enabledIds = new HashSet(activityManager.getEnabledActivityIds());
        Hashtable availableCategories = CategoriesContentProvider.categoryManager
                .getAvailableCategories();

        CategoryPresentation categoryPresentation = (CategoryPresentation) availableCategories
                .get(category.getId());
        disableCategoryActivities(enabledIds, categoryPresentation);

        // now disable all activities in implicitly disabled categories.
        Hashtable implicitlyDisabledCategoriesMap = CategoriesContentProvider.categoryManager
                .getImplicitlyDisabledCategoriesMap();
        if (implicitlyDisabledCategoriesMap.containsKey(category.getId())) {
            Vector implicitlyDisabledCategories = (Vector) implicitlyDisabledCategoriesMap
                    .get(category.getId());
            for (int i = 0; i < implicitlyDisabledCategories.size(); i++) {
                CategoryPresentation aCategoryPresentation = (CategoryPresentation) availableCategories
                        .get(implicitlyDisabledCategories.elementAt(i));
                disableCategoryActivities(enabledIds, aCategoryPresentation);
            }
        }

        // update the current set of enabled activities.
        workbenchActivitySupport.setEnabledActivityIds(enabledIds);
    }


    private void disableCategoryActivities(Set enabledIds,
            CategoryPresentation categoryPresentation) {

        Vector activities = categoryPresentation.getAllActivities();
        for (int i = 0; i < activities.size(); i++)
            enabledIds.remove(activities.elementAt(i));
    }



    private void disableSelectedCategory(ICategory category) {
        Set enabledIds = new HashSet(activityManager.getEnabledActivityIds());

        CategoryPresentation categoryPresentation = (CategoryPresentation) CategoriesContentProvider.categoryManager
                .getAvailableCategories().get(category.getId());
        Vector activitiesToRemove = categoryPresentation.getAllActivities();

        // Get all the affected categories. For each category, get all
        // activities and remove them from the list of activities that needs to
        // be removed.
        Hashtable implicitlyDisabledCategoriesMap = CategoriesContentProvider.categoryManager
                .getImplicitlyDisabledCategoriesMap();
        Vector implicitlyDisabledCategories = (Vector) implicitlyDisabledCategoriesMap
                .get(category.getId());
        for (int i = 0; i < implicitlyDisabledCategories.size(); i++) {
            CategoryPresentation aCategoryPresentation = (CategoryPresentation) CategoriesContentProvider.categoryManager
                    .getAvailableCategories().get(
                            implicitlyDisabledCategories.elementAt(i));
            if (!aCategoryPresentation.isCategoryEnabled())
                // if the affected category is not enabled, nothing to do.
                continue;
            Vector aActivities = aCategoryPresentation.getAllActivities();
            for (int j = 0; j < aActivities.size(); j++)
                activitiesToRemove.remove(aActivities.elementAt(j));
        }

        // now remove the remaining activities.
        for (int i = 0; i < activitiesToRemove.size(); i++)
            enabledIds.remove(activitiesToRemove.elementAt(i));

        // update the current set of enabled activities
        workbenchActivitySupport.setEnabledActivityIds(enabledIds);
    }



    private void enableCategory(ICategory category) {
        Set enabledIds = new HashSet(activityManager.getEnabledActivityIds());
        // enable all activities in this category. Enabling an activity
        // enables all required activities by this api call.
        Set activities = category.getCategoryActivityBindings();
        for (Iterator it = activities.iterator(); it.hasNext();) {
            ICategoryActivityBinding binding = (ICategoryActivityBinding) it
                    .next();
            if (!enabledIds.contains(binding.getActivityId())) {
                enabledIds.add(binding.getActivityId());
            }
        }
        // update the current set of enabled activities
        workbenchActivitySupport.setEnabledActivityIds(enabledIds);
    }



}



