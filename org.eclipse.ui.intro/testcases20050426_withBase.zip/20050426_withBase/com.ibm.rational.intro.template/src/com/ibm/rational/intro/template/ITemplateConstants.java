package com.ibm.rational.intro.template;


public interface ITemplateConstants {

    /**
     * categoryIcon Extension point id. and all the attributes of the extension
     * point.
     */
    String CATEGORY_ICON_EXT_POINT = "com.ibm.rational.intro.template.categoryIcon";
    String ATT_CATEGORY_ID = "categoryId";
    String ATT_PLUGIN_ID = "pluginId";
    String ATT_ICON = "icon";

    String ROLE_CONTAINER_ID = "";
    String EMPTY_STRING = "";

    /* HTML attributes */
    String ATTR_ONMOUSEOVER = "onMouseover";
    String ATTR_ONMOUSEOUT = "onMouseout";
    String ATTR_ONCLICK = "onClick";
    String ATTR_ONFOCUS = "onFocus";
    String ATTR_ONKEYPRESS = "onKeyPress";
    String ATTR_ONBLUR = "onBlur";



    /* HTML attribute values */
    String ID_ROLE_SELECTION = "role-selection";
    String ID_ROLE_TEXT = "role-text";
    String ID_ROLE_TITLE = "role-title";
    String ID_ROLE_TITLE_CONTENT = "role-title-content";
    String ID_ROLE_DESCRIPTION = "role-description";
    String ID_ROLE_DESCRIPTION_CONTENT = "role-description-content";
    String ID_AVAILABLE_ROLES = "available-roles";
    String ID_BACKGROUND_FILL = "background-fill";
    String ID_ACTIVE_ROLES_TRAY = "active-roles-tray";
    String ID_ROLE_TEXT_CONTENT = "role-text-content";
    String ID_ROLES_CURVE = "roles-curve";
    String ID_ENABLED_ROLES = "enabled-roles";
    String ID_ROLE_GUY = "role-guy";
    String ID_ROLE_GUY_DESCRIPTION = "role-guy-description";
    String ID_ENABLE_TITLE = "enable-title";
    String ID_ENABLE_DESCRIPTION = "enable-description";
    String ID_CATEGORY_DESCRIPTION = "category-description";


    String CLASS_ROLE_LINK = "role-link";
    String CLASS_ROLE_STYLE = "role-style";
    String CLASS_TOGGLE_ON = "toggle-on";
    String CLASS_TOGGLE_OFF = "toggle-off";
    String ID_ENABLED = "enabled";
    String ID_DISABLED = "disabled";
    String ID_ENABLED_PARENT = "enabled-parent";
    String ID_DISABLED_PARENT = "disabled-parent";

    String ROLE_GUY_IMG_SRC = "css/graphics/user roles/tray/role.gif";
    String ROLE_GUY_HOVER_IMG_SRC = "css/graphics/user roles/tray/rolehov.gif";
    String ID_ROLE_GUY_IMG = "role-guy-image";
    String ROLE_GUY_ALT_TEXT = "Enable/disable roles";


    /* JavaScript method names */
    String JS_SHOW_TEXT = "show_text";
    String JS_SHOW_MULTI_TEXT = "show_multiple_text";
    String JS_RESET_TEXT = "reset_text";
    String JS_TOGGLE_CLASS = "toggle_element_class";
    String JS_SWITCH_IMAGE_SRC = "switch_image_src";
    String JS_TOGGLE_ROLE_GUY = "toggle_role_guy";
    String JS_SHOW_ELEMENT = "show_element";
    String JS_HIDE_ELEMENT = "hide_element";
    String JS_HANDLE_CATEGORY_MOUSE_OVER = "handle_category_mouseover";
    String JS_HANDLE_CATEGORY_MOUSE_OUT = "handle_category_mouseout";
    String JS_ONMOUSEOVER_ROLE_GUY = "onMouseover_role_guy";
    String JS_ONKEYPRESS_TOGGLE_ROLE_GUY = "onKeyPress_toggle_role_guy";
   


}



