package com.ibm.rational.intro.template;

import java.util.*;

import org.eclipse.ui.*;
import org.eclipse.ui.activities.*;


public class CategoryManager {


    // Keys are category id. Values are a vector of category ids that can be
    // implicitly enabled by the category key. A category is implicitly enabled
    // by another category if all its activities and required activities can be
    // enabled by the first category (and all its
    private Hashtable implicitlyEnabledCategoriesMap;

    // Keys are category id. Values are a vector of category ids that can be
    // implicitly disabled by the category key.
    private Hashtable implicitlyDisabledCategoriesMap;

    protected IActivityManager activityManager;

    // Keys are category id. Values are CategoryPresentation.
    private Hashtable availableCategories;


    public CategoryManager() {
        this.activityManager = PlatformUI.getWorkbench().getActivitySupport()
                .getActivityManager();
        // loads all categories and checks which are enabled. Has to be recalled
        // every time we regen the page.
        availableCategories = createCategoryPresentations();
        implicitlyEnabledCategoriesMap = computeImplicitlyEnabledCategories();
        implicitlyDisabledCategoriesMap = computeImplicitlyDisabledCategories();
    }

    /**
     * Create a collection of all available categories
     */
    private Hashtable createCategoryPresentations() {
        Hashtable availableCategories = new Hashtable();
        Set categoryIds = activityManager.getDefinedCategoryIds();
        for (Iterator it = categoryIds.iterator(); it.hasNext();) {
            String id = (String) it.next();
            ICategory category = activityManager.getCategory(id);
            CategoryPresentation presentation = new CategoryPresentation(
                    activityManager, category);
            availableCategories.put(id, presentation);
        }
        // needed to refresh the content of the instance var when an activity
        // change event happens.
        this.availableCategories = availableCategories;
        return availableCategories;
    }


    public Hashtable getAvailableCategories() {
        return availableCategories;
    }


    public Hashtable getImplicitlyEnabledCategoriesMap() {
        return implicitlyEnabledCategoriesMap;
    }

    public Hashtable getImplicitlyDisabledCategoriesMap() {
        return implicitlyDisabledCategoriesMap;
    }


    /**
     * Create the hashtable of all categories that can be implicitly enabled.
     */
    public Hashtable computeImplicitlyEnabledCategories() {
        Hashtable implicitlyEnabledCategories = new Hashtable();
        // vector that will hold mapping of a category and the categories it
        // enables.
        Set categoryIds = activityManager.getDefinedCategoryIds();

        for (Iterator it = categoryIds.iterator(); it.hasNext();) {
            // for every category, get _all_ its activities, and see if these
            // activities are enough to enable another category.
            String currentCategoryId = (String) it.next();
            CategoryPresentation categoryPresentation = (CategoryPresentation) availableCategories
                    .get(currentCategoryId);
            Vector currentCategoryActivities = categoryPresentation
                    .getAllActivities();

            // this vector will hold all categories enabled by a given
            // category.
            Vector enabledCategories = new Vector();

            for (Iterator it2 = categoryIds.iterator(); it2.hasNext();) {
                String aCategoryId = (String) it2.next();
                // skip the current category we are in.
                if (aCategoryId.equals(currentCategoryId))
                    continue;

                CategoryPresentation aCategoryPresentation = (CategoryPresentation) availableCategories
                        .get(aCategoryId);
                Vector aCategoryActivities = aCategoryPresentation
                        .getAllActivities();
                if (aCategoryActivities.size() > currentCategoryActivities
                        .size())
                    // the current category has less activities than the
                    // category we are iterating against. so it can not enable
                    // this category.
                    continue;

                boolean isDependent = true;
                for (int i = 0; i < aCategoryActivities.size(); i++) {
                    if (!currentCategoryActivities.contains(aCategoryActivities
                            .get(i))) {
                        isDependent = false;
                        break;
                    }
                }
                if (isDependent)
                    enabledCategories.add(aCategoryId);

            }
            if (enabledCategories.size() != 0)
                implicitlyEnabledCategories.put(currentCategoryId,
                        enabledCategories);

        }
        return implicitlyEnabledCategories;
    }



    /**
     * Create the hashtable of all categories that can be implicitly disabled.
     */
    public Hashtable computeImplicitlyDisabledCategories() {
        Hashtable implicitlyDisabledCategories = new Hashtable();
        // vector that will hold mapping of a category and the categories it
        // disables.
        Set categoryIds = activityManager.getDefinedCategoryIds();
        for (Iterator it = categoryIds.iterator(); it.hasNext();) {
            // for every category, get _all_ required activities its and see if
            // any of these activities will disable a given category.
            String currentCategoryId = (String) it.next();

            CategoryPresentation categoryPresentation = (CategoryPresentation) availableCategories
                    .get(currentCategoryId);
            Vector currentCategoryActivities = categoryPresentation
                    .getAllActivities();

            // this vector will hold all categories disabled by the current
            // category.
            Vector disabledCategories = new Vector();

            for (Iterator it2 = categoryIds.iterator(); it2.hasNext();) {
                String aCategoryId = (String) it2.next();
                // skip the current category we are in.
                if (aCategoryId.equals(currentCategoryId))
                    continue;

                // get _all_ activities of this category and see if any match
                // the current list of activities.
                CategoryPresentation aCategoryPresentation = (CategoryPresentation) availableCategories
                        .get(aCategoryId);
                Vector aCategoryActivities = aCategoryPresentation
                        .getAllActivities();

                boolean isDependent = false;
                for (int i = 0; i < currentCategoryActivities.size(); i++) {
                    if (aCategoryActivities.contains(currentCategoryActivities
                            .get(i))) {
                        isDependent = true;
                        break;
                    }
                }
                if (isDependent)
                    disabledCategories.add(aCategoryId);

            }
            if (disabledCategories.size() != 0)
                implicitlyDisabledCategories.put(currentCategoryId,
                        disabledCategories);

        }
        return implicitlyDisabledCategories;
    }



    public boolean categoryIsParent(String categoryId) {
        return implicitlyEnabledCategoriesMap.containsKey(categoryId);
    }

    public boolean categoryCanImplicitDisable(String categoryId) {
        if (!implicitlyDisabledCategoriesMap.containsKey(categoryId))
            // category does not affect any other category.
            return false;

        // category can affect other categories. Return true if any of the
        // categories it affects is enabled.
        Vector implicitlyDisabledCategories = (Vector) implicitlyDisabledCategoriesMap
                .get(categoryId);
        for (int i = 0; i < implicitlyDisabledCategories.size(); i++) {
            CategoryPresentation categoryPresentation = (CategoryPresentation) availableCategories
                    .get(implicitlyDisabledCategories.elementAt(i));
            if (categoryPresentation.isCategoryEnabled())
                return true;
        }
        return false;
    }

    public boolean categoryIsLocked(String categoryId) {
        boolean categoryIsLocked = false;
        CategoryPresentation categoryPresentation = (CategoryPresentation) CategoriesContentProvider.categoryManager
                .getAvailableCategories().get(categoryId);
        if (!categoryPresentation.isCategoryEnabled())
            // if category is not enabled, it can not be locked.
            return false;

        for (Enumeration en = implicitlyEnabledCategoriesMap.keys(); en
                .hasMoreElements();) {
            String key = (String) en.nextElement();
            Vector implicitCategories = (Vector) implicitlyEnabledCategoriesMap
                    .get(key);
            if (implicitCategories.contains(categoryId)) {
                // this is a category that can be implicitly enabled by
                // another category. find out which category can enable it, and
                // if that category is enabled, then this category is locked.
                CategoryPresentation presentation = (CategoryPresentation) availableCategories
                        .get(key);
                if (presentation.isCategoryEnabled()) {
                    // we have an enabled parent category for the current
                    // category. this means that the current category is
                    // locked.
                    categoryIsLocked = true;
                    break;
                }

            }
        }
        return categoryIsLocked;
    }



    /*
     * Update the enablement state of the categories. For performance, this
     * should be the only thing to be re-computed.
     */
    public void activityManagerChanged() {
        for (Enumeration en = availableCategories.elements(); en
                .hasMoreElements();) {
            CategoryPresentation presentation = (CategoryPresentation) en
                    .nextElement();
            presentation.updateEnabledState();
        }
    }
}



