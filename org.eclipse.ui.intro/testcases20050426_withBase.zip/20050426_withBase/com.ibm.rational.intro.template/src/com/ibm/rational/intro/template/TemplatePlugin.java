package com.ibm.rational.intro.template;

import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

import org.eclipse.core.runtime.*;
import org.eclipse.ui.internal.intro.impl.util.*;
import org.eclipse.ui.plugin.*;
import org.osgi.framework.*;


public class TemplatePlugin extends AbstractUIPlugin {
    //	 The template resource bundle.
    public static String TEMPLATE_BUNDLE = "com.ibm.rational.intro.template"; //$NON-NLS-1$
    public static String TEMPLATE_RESOURCE_BUNDLE = "com.ibm.rational.intro.template.resources"; //$NON-NLS-1$

    //  There should always be a single instance of all these classes.
    private ResourceBundle resourceBundle;

    //  The static shared instance.
    private static TemplatePlugin inst;

    // Hashtable where key is the categoryId and value id the resolved category
    // icon path.
    Hashtable categoryIcons = new Hashtable();

    /**
     * The constructor.
     */
    public TemplatePlugin() {
        super();
    }


    /**
     * Returns the shared plugin instance.
     */
    public static TemplatePlugin getDefault() {
        return inst;
    }

    /**
     * Returns the string from the plugin's resource bundle, or 'key' if not
     * found.
     */
    public static String getString(String key) {
        try {
            ResourceBundle bundle = TemplatePlugin.getDefault()
                    .getResourceBundle();
            return (bundle != null ? bundle.getString(key) : key);
        } catch (MissingResourceException e) {
            // ok to return Key.
            return key;
        }
    }

    /**
     * Utility method to get a resource from the given key, then format it with
     * the given substitutions. <br>
     */
    public static String getFormattedString(String key, Object[] args) {
        return MessageFormat.format(getString(key), args);
    }

    /**
     * Returns the plugin's resource bundle.
     */
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
     */
    public void start(BundleContext context) throws Exception {
        super.start(context);
        inst = this;
        loadCategoryIconExtension();
        try {
            resourceBundle = ResourceBundle.getBundle(TEMPLATE_RESOURCE_BUNDLE);
        } catch (MissingResourceException x) {
            resourceBundle = null;
            Log.warning("IntroPlugin - unable to load resource bundle"); //$NON-NLS-1$
        }


    }


    /*
     * (non-Javadoc)
     * 
     * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
     */
    public void stop(BundleContext context) throws Exception {
        super.stop(context);
    }


    private void loadCategoryIconExtension() {
        IConfigurationElement[] configElements = Platform
                .getExtensionRegistry().getConfigurationElementsFor(
                        ITemplateConstants.CATEGORY_ICON_EXT_POINT);

        for (int i = 0; i < configElements.length; i++) {
            IConfigurationElement configElement = configElements[i];
            String categoryId = configElement
                    .getAttribute(ITemplateConstants.ATT_CATEGORY_ID);
            if (categoryId == null)
                continue;
            String pluginId = configElement
                    .getAttribute(ITemplateConstants.ATT_PLUGIN_ID);
            if (pluginId == null)
                pluginId = TemplatePlugin.TEMPLATE_BUNDLE;
            String icon = configElement
                    .getAttribute(ITemplateConstants.ATT_ICON);
            if (icon == null)
                continue;
            String iconPath = getResolvedIconPath(pluginId, icon);
            if (!categoryIcons.containsKey(categoryId))
                categoryIcons.put(categoryId, iconPath);
        }

    }

    public String getCategoryIcon(String categoryId) {
        if (categoryIcons.containsKey(categoryId))
            return (String) categoryIcons.get(categoryId);

        // category does not have an icon defined, return default icon.
        return getResolvedIconPath(TemplatePlugin.TEMPLATE_BUNDLE,
                "css/graphics/user roles/icons/eclipse.gif");

    }



    protected String getResolvedIconPath(String bundleId, String url) {
        if (bundleId == null || url == null)
            return "";

        Bundle bundle = Platform.getBundle(bundleId);
        if (bundle == null)
            return "";

        URL imageUrl = Platform.find(bundle, new Path(url));
        if (imageUrl == null)
            return "";
        try {
            imageUrl = Platform.asLocalURL(imageUrl);
        } catch (IOException e) {
        }

        if (imageUrl != null)
            return imageUrl.toExternalForm();
        else
            return "";
    }

}