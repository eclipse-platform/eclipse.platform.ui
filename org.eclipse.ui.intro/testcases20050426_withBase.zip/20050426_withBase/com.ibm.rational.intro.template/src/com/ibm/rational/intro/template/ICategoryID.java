
package com.ibm.rational.intro.template;


public interface ICategoryID {

    String DEVELOPMENT_CATEGORY_ID = "org.eclipse.categories.developmentCategory";
    String TEAM_CATEGORY_ID = "org.eclipse.categories.teamCategory";

}