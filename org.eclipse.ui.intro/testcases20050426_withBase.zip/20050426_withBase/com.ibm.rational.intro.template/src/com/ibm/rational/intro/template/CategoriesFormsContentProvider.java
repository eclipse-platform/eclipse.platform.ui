
package com.ibm.rational.intro.template;

import org.eclipse.swt.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.forms.widgets.*;

/**
 * Provides SWT/Forms content to expose categories of activites in an intro.
 */
public class CategoriesFormsContentProvider {

    /*
     * This method must be implemented if the intro uses the SWT implementation
     * as a fallback, or exclusively on certain platforms
     */
    public void createContent(String id, Composite parent, FormToolkit toolkit) {
        Label label1 = toolkit.createLabel(parent, "first test", SWT.WRAP);
        Label label2 = toolkit.createLabel(parent, "second test", SWT.WRAP);

    }



}