package com.ibm.rational.intro.template;

import java.io.*;
import java.util.*;

import org.eclipse.ui.internal.intro.impl.html.*;

/**
 * Provides HTML content to expose categories of activities in an intro.
 * 
 * One div is created that shows all of the categories/roles that are currently
 * enabled (a category is considered to be enabled if all activities in that
 * category are enabled).
 * 
 * Another div is created that shows all of the available categories. The
 * categories in this div are displayed differently depending on whether they
 * are currently enabled or disabled. Each category in this div is represented
 * as a link, and clicking the link executes a command that either enables or
 * disables the associated category.
 */
public class CategoriesHTMLContentProvider {
    private Hashtable availableCategories;

    public void createContent(Hashtable categories, String id, PrintWriter out) {
        availableCategories = categories;
        int indentLevel = 3;
        HTMLElement categorySelection = createCategorySelectionDiv(indentLevel);
        HTMLElement parentCategoryDescription = createParentCategoryDiv(indentLevel);
        HTMLElement roleIconDescription = createRoleIconHoverLabelDiv(indentLevel);
        HTMLElement activeCategoriesTray = createActiveCategoriesDiv(indentLevel);

        out.write(categorySelection.toString());
        out.write(parentCategoryDescription.toString());
        out.write(roleIconDescription.toString());
        out.write(activeCategoriesTray.toString());
    }

    /**
     * Creates a Java Script function call to the function specified in
     * <code>functionName</code> with the parameters specified in
     * <code>params</code>. All String params will be wrapped in single
     * quotes
     * 
     * @param functionName
     * @param params
     * @return
     */
    protected static String createJavaScriptCall(String functionName,
            ArrayList params) {
        if (functionName == null)
            return "";
        StringBuffer jsFunctionCall = new StringBuffer(functionName + "(");
        if (params != null) {
            for (Iterator it = params.iterator(); it.hasNext();) {
                Object p = it.next();
                if (p instanceof String) {
                    String param = (String) p;
                    jsFunctionCall.append("\'" + param + "\'");
                } else {
                    jsFunctionCall.append(p);
                }
                if (it.hasNext())
                    jsFunctionCall.append(",");
            }
        }
        jsFunctionCall.append(")");

        return jsFunctionCall.toString();
    }

    /**
     * Generate an HTML anchor element: &lt;A id=linkId class=linkClass
     * href=linkHref&gt; &lt;/A&gt;
     * 
     * @param id
     *            the id of this link
     * @param url
     *            the href of this link
     * @param style
     *            the CSS class of this link
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateAnchorElement(String id, String url,
            String style, int indentLevel) {

        HTMLElement anchor = new FormattedHTMLElement(
                IIntroHTMLConstants.ELEMENT_ANCHOR, indentLevel, true);
        if (id != null)
            anchor.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ID, id);
        if (url != null)
            anchor.addAttribute(IIntroHTMLConstants.ATTRIBUTE_HREF, url);
        if (style != null)
            anchor.addAttribute(IIntroHTMLConstants.ATTRIBUTE_CLASS, style);
        else
            anchor.addAttribute(IIntroHTMLConstants.ATTRIBUTE_CLASS,
                    IIntroHTMLConstants.ANCHOR_CLASS_LINK);

        return anchor;
    }

    /**
     * Generate an HTML div element: &lt;DIV id=divId class=divClass&gt;
     * &lt;/DIV&gt;
     * 
     * @param divId
     *            the id of this div
     * @param divClass
     *            the CSS class of this div
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateDivElement(String divId, String divClass,
            int indentLevel) {
        HTMLElement div = new FormattedHTMLElement(
                IIntroHTMLConstants.ELEMENT_DIV, indentLevel, true);
        if (divId != null)
            div.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ID, divId);
        if (divClass != null)
            div.addAttribute(IIntroHTMLConstants.ATTRIBUTE_CLASS, divClass);
        return div;
    }

    /**
     * Generate an HTML image element: &lt;IMG src=imageSrc id=imageId
     * alt=altText class=imageClass&gt;
     * 
     * @param imageSrc
     *            the src of the image
     * @param imageId
     *            the id of the image
     * @param altText
     *            the alternative text for this image
     * @param imageClass
     *            the class for this image
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateImageElement(String imageSrc,
            String imageId, String altText, String imageClass, int indentLevel) {
        HTMLElement image = new FormattedHTMLElement(
                IIntroHTMLConstants.ELEMENT_IMG, indentLevel, true, false);
        image.addAttribute(IIntroHTMLConstants.ATTRIBUTE_SRC, imageSrc);
        if (imageId != null)
            image.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ID, imageId);
        if (altText == null)
            altText = ""; //$NON-NLS-1$
        image.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ALT, altText);
        if (imageClass != null)
            image.addAttribute(IIntroHTMLConstants.ATTRIBUTE_CLASS, imageClass);
        return image;
    }

    /**
     * Generates an HTML anchor element that represents an eclipse Category.
     * 
     * @param categoryId
     * @param imageURL
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateCategoryLinkElement(String categoryId,
            String imageURL, int indentLevel) {
        return generateCategoryLinkElement(categoryId, null, imageURL, null,
                indentLevel);
    }

    /**
     * Generates an HTML anchor element that represents an eclipse Category. The
     * anchor will contain an image element. The href for the link is an
     * IntroURL action that will programmatically change the state of the
     * associated category (i.e., if the category was enabled before the user
     * clicked this link, then the action will disable the category):
     * <p>
     * &lt;A id=categoryId class=role-style
     * href=http://org.eclipse.ui.intro/runAction?pluginId=foo&class=CategoryStateChanged&categoryId=id&gt;
     * &lt;IMG src=imageSrc id=imageId alt=altText class=imageClass&gt;
     * &lt;/A&gt;
     * </p>
     * 
     * @param categoryId
     *            the id of the category this link represents
     * @param imageId
     *            the id of the HTML image element this link will contain
     * @param imageURL
     *            the src of the HTML image element this link will contain
     * @param imageAltText
     *            the altText of the HTML image element this link will contain
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateCategoryLinkElement(String categoryId,
            String imageClassId, String imageURL, String imageAltText,
            int indentLevel) {
        // create url:
        String url = "http://org.eclipse.ui.intro/runAction?pluginId="
                + TemplatePlugin.TEMPLATE_BUNDLE
                + "&amp;class=com.ibm.rational.intro.template.CategoryStateChanged&amp;categoryId="
                + categoryId;
        String style = ITemplateConstants.CLASS_ROLE_STYLE;
        HTMLElement anchor = generateAnchorElement(categoryId, url, style,
                indentLevel + 1);
        // add <IMG src=imageSrc id=imageId alt=altText>
        if (imageURL != null) {
            HTMLElement image = generateImageElement(imageURL, null, null,
                    imageClassId, indentLevel + 1);
            if (image != null) {
                if (imageAltText != null)
                    image.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ALT,
                            imageAltText);
                anchor.addContent(image);
            }
        }
        return anchor;
    }


    /**
     * Generates an HTML anchor element that represents an eclipse enabled
     * Category, placed in the role tray. The anchor will contain an image
     * element. The href for the link is a no-op to duplicate the same look and
     * feel of the role-selection fly-out. A click on the image embedded in the
     * link toggles the state of the role-selection div.
     * 
     * @param imageURL
     *            the src of the HTML image element this link will contain
     * @param imageAltText
     *            the altText of the HTML image element this link will contain
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateEnabledCategoryLinkTrayElement(
            String imageURL, String imageAltText, int indentLevel) {
        // create url:
        String url = "http://org.eclipse.ui.intro/runAction";
        String style = ITemplateConstants.CLASS_ROLE_STYLE;
        HTMLElement anchor = generateAnchorElement("", url, style,
                indentLevel + 1);
        // add <IMG src=imageSrc id=imageId alt=altText>
        if (imageURL != null) {
            HTMLElement image = generateImageElement(imageURL, null, null,
                    null, indentLevel + 1);
            if (image != null) {
                if (imageAltText != null)
                    image.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ALT,
                            imageAltText);
                anchor.addContent(image);

                // add onClick attribute to image.
                ArrayList params = new ArrayList(1);
                params.add(ITemplateConstants.ID_ROLE_SELECTION);
                params.add(ITemplateConstants.ID_ROLE_GUY_DESCRIPTION);
                String mouseEventCall = createJavaScriptCall(
                        ITemplateConstants.JS_TOGGLE_ROLE_GUY, params);
                if (mouseEventCall != null)
                    image.addAttribute(ITemplateConstants.ATTR_ONCLICK,
                            mouseEventCall);

            }
        }
        return anchor;
    }


    /**
     * Generate an HTML SPAN element: &lt;SPAN id=spanId class=spanClass&gt;
     * &lt;/SPAN&gt;
     * 
     * @param spanId
     * @param spanClass
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateSpanElement(String spanId,
            String spanClass, String textContent, int indentLevel) {
        HTMLElement span = new FormattedHTMLElement(
                IIntroHTMLConstants.ELEMENT_SPAN, indentLevel, false);
        if (spanId != null)
            span.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ID, spanId);
        if (spanClass != null)
            span.addAttribute(IIntroHTMLConstants.ATTRIBUTE_CLASS, spanClass);
        if (textContent != null)
            span.addContent(textContent);
        return span;
    }



    /**
     * Generate a text element. Could be a &lt;P&gt;, &lt;H1&gt;, &lt;H2&gt;,
     * etc. The text element will contain an HTML span element, which will wrap
     * the text content:
     * <p>
     * &lt;P&gt;&lt;SPAN&gt;textContent&lt;/SPAN&gt;&lt;/P&gt;
     * </p>
     * 
     * @param type
     *            the type of this text element (e.g., p, h1, h2, etc)
     * @param spanID
     *            the id of the inner SPAN element
     * @param spanClass
     *            the class of the inner SPAN element
     * @param textContent
     *            the textual content
     * @param indentLevel
     * @return
     */
    public static HTMLElement generateTextElement(String type, String spanID,
            String spanClass, String textContent, int indentLevel) {
        // Create the span: <SPAN>textContent</SPAN>
        HTMLElement span = new HTMLElement(IIntroHTMLConstants.ELEMENT_SPAN);
        if (spanID != null)
            span.addAttribute(IIntroHTMLConstants.ATTRIBUTE_ID, spanID);
        if (spanClass != null)
            span.addAttribute(IIntroHTMLConstants.ATTRIBUTE_CLASS, spanClass);
        if (textContent != null)
            span.addContent(textContent);
        // Create the enclosing text element: <P><SPAN>spanContent</SPAN></P>
        HTMLElement text = new FormattedHTMLElement(type, indentLevel, false);
        text.addContent(span);
        return text;
    }



    /**
     * Create the main category selection div. This div has 3 main sections:
     * <p>
     * 1. section at the top that shows a title and description of the current
     * category.
     * </p>
     * <p>
     * 2. the main section that shows all of the available categories, and
     * allows users to enable or disable categories by clicking on the link
     * associated with a given category.
     * </p>
     * <p>
     * 3. a section at the bottom that just contains background fill. This
     * section is only used to make it look as if this div extends all the way
     * down to the top of the next div
     * </p>
     * 
     * @param indentLevel
     * @return
     */
    protected HTMLElement createCategorySelectionDiv(int indentLevel) {

        HTMLElement selectionDiv = generateDivElement(
                ITemplateConstants.ID_ROLE_SELECTION,
                ITemplateConstants.CLASS_TOGGLE_OFF, indentLevel);

        // add the role-text div
        HTMLElement roleTextDiv = createRoleTextDiv(indentLevel + 1);
        selectionDiv.addContent(roleTextDiv);

        // add the available-roles div
        HTMLElement avaialableRoles = createAvailableCategoriesDiv(indentLevel + 1);
        selectionDiv.addContent(avaialableRoles);

        // add the background-fill div
        HTMLElement backgroundDiv = generateDivElement(
                ITemplateConstants.ID_BACKGROUND_FILL, null, indentLevel + 1);
        selectionDiv.addContent(backgroundDiv);

        return selectionDiv;
    }

    /**
     * This div displays the title and description of the category that is
     * currently being hovered over. When no category is being hovered over, a
     * generic title and description are displayed. This div is appears at the
     * top of the category-selection div.
     * 
     * @param indentLevel
     * @return
     */
    protected HTMLElement createRoleTextDiv(int indentLevel) {
        HTMLElement roleTextDiv = generateDivElement(
                ITemplateConstants.ID_ROLE_TEXT, null, indentLevel);

        // add the role-title
        HTMLElement roleTitle = generateTextElement(
                IIntroHTMLConstants.ELEMENT_H3,
                ITemplateConstants.ID_ROLE_TITLE_CONTENT, null, TemplatePlugin
                        .getString("default_role_title"), indentLevel + 1);
        roleTextDiv.addContent(roleTitle);

        // add the role-description
        HTMLElement roleDesc = generateTextElement(
                IIntroHTMLConstants.ELEMENT_PARAGRAPH,
                ITemplateConstants.ID_ROLE_DESCRIPTION_CONTENT, null,
                TemplatePlugin.getString("default_role_description"),
                indentLevel + 1);
        roleTextDiv.addContent(roleDesc);

        return roleTextDiv;
    }

    protected HTMLElement createAvailableCategoriesDiv(int indentLevel) {
        HTMLElement availableRoles = generateDivElement(
                ITemplateConstants.ID_AVAILABLE_ROLES, null, indentLevel);

        // create a link element for each available role
        for (Enumeration en = availableCategories.elements(); en
                .hasMoreElements();) {
            CategoryPresentation presentation = (CategoryPresentation) en
                    .nextElement();

            // Create the link. Make sure to choose correct state.
            String imageClassId = presentation.getCategoryState();
            HTMLElement link = generateCategoryLinkElement(presentation
                    .getCategoryId(), imageClassId, presentation.getIconPath(),
                    presentation.getCategoryName(), indentLevel + 1);
            if (link != null) {
                // add onMouseOver attribute:
                String mouseEventCall = handleCategoryMouseOverJSCall(
                        presentation.getCategoryName(), presentation
                                .getCategoryDescription(), imageClassId);
                if (mouseEventCall != null)
                    link.addAttribute(ITemplateConstants.ATTR_ONMOUSEOVER,
                            mouseEventCall);


                // add onFocus attribute:
                mouseEventCall = handleCategoryMouseOverJSCall(presentation
                        .getCategoryName(), presentation
                        .getCategoryDescription(), imageClassId);
                if (mouseEventCall != null)
                    link.addAttribute(ITemplateConstants.ATTR_ONFOCUS,
                            mouseEventCall);


                // add onMouseOut/onBlur attributes:
                mouseEventCall = handleCategoryMouseOutJSCall(TemplatePlugin
                        .getString("default_role_title"), TemplatePlugin
                        .getString("default_role_description"));
                if (mouseEventCall != null)
                    link.addAttribute(ITemplateConstants.ATTR_ONMOUSEOUT,
                            mouseEventCall);
                if (mouseEventCall != null)
                    link.addAttribute(ITemplateConstants.ATTR_ONBLUR,
                            mouseEventCall);

                availableRoles.addContent(link);
            }
        }
        return availableRoles;
    }

    private String showTextJSCall(String text) {
        ArrayList params = new ArrayList(2);
        params.add(0, ITemplateConstants.ID_ROLE_TEXT_CONTENT);
        params.add(1, text);
        return createJavaScriptCall(ITemplateConstants.JS_SHOW_TEXT, params);
    }


    /*
     * Creates a Java Script function call to show_multiple_text(elementId1,
     * text1, elementId2, text2)
     */
    private String showMultipleTextJSCall(String value1, String value2) {
        ArrayList params = new ArrayList(2);
        params.add(ITemplateConstants.ID_ROLE_TITLE_CONTENT);
        params.add(value1);
        params.add(ITemplateConstants.ID_ROLE_DESCRIPTION_CONTENT);
        params.add(value2);

        return createJavaScriptCall(ITemplateConstants.JS_SHOW_MULTI_TEXT,
                params);
    }


    /*
     * Creates a Java Script function call to
     * handle_category_mouseover(elementId1, text1, elementId2, text2,
     * elementId3, text3)
     */
    private String handleCategoryMouseOverJSCall(String value1, String value2,
            String state) {
        ArrayList params = new ArrayList(2);
        params.add(ITemplateConstants.ID_ROLE_TITLE_CONTENT);
        params.add(value1);
        params.add(ITemplateConstants.ID_ROLE_DESCRIPTION_CONTENT);
        params.add(value2);
        params.add(ITemplateConstants.ID_CATEGORY_DESCRIPTION);
        if (state.equals(CategoryPresentation.STATE_ENABLED_IMPLICITDISABLE))
            params.add(TemplatePlugin
                    .getString("disable_parent_category_description"));
        else if (state.equals(CategoryPresentation.STATE_DISABLED_PARENT))
            params.add(TemplatePlugin
                    .getString("enable_parent_category_description"));
        else if (state.equals(CategoryPresentation.STATE_ENABLED_LOCKED))
            params.add(TemplatePlugin
                    .getString("parent_category_locked_description"));
        else
            params.add("");

        return createJavaScriptCall(
                ITemplateConstants.JS_HANDLE_CATEGORY_MOUSE_OVER, params);
    }

    /*
     * Creates a Java Script function call to
     * handle_category_mouseout(elementId1, text1, elementId2, text2,
     * elementId3)
     */
    private String handleCategoryMouseOutJSCall(String value1, String value2) {
        ArrayList params = new ArrayList(2);
        params.add(ITemplateConstants.ID_ROLE_TITLE_CONTENT);
        params.add(value1);
        params.add(ITemplateConstants.ID_ROLE_DESCRIPTION_CONTENT);
        params.add(value2);
        params.add(ITemplateConstants.ID_CATEGORY_DESCRIPTION);

        return createJavaScriptCall(
                ITemplateConstants.JS_HANDLE_CATEGORY_MOUSE_OUT, params);
    }


    /**
     * This will generate a div that will be used to display some description
     * when the user hovers over a parent category. A parent category is one
     * whereby enabling it enables other smaller categories.
     * 
     * @param indentLevel
     * @return
     */
    protected HTMLElement createParentCategoryDiv(int indentLevel) {

        HTMLElement categoryDescDiv = generateDivElement(
                ITemplateConstants.ID_CATEGORY_DESCRIPTION,
                ITemplateConstants.CLASS_TOGGLE_OFF, indentLevel);

        // add the category description paragraph.
        //HTMLElement content = generateSpanElement(null, null, TemplatePlugin
        //        .getString("enable_parent_category_description"),
         //       indentLevel + 1);
        HTMLElement content = generateSpanElement(null, null, "",
                indentLevel + 1);

        // Create the enclosing text element: <P><SPAN>spanContent</SPAN></P>
        HTMLElement text = new FormattedHTMLElement(
                IIntroHTMLConstants.ELEMENT_PARAGRAPH, indentLevel + 1, false);
        text.addContent(content);

        categoryDescDiv.addContent(text);

        return categoryDescDiv;
    }


    /**
     * This will generate a div that will be used to display some description
     * when the user hovers over the Role-Dude icon. It will be used to show
     * text that will tell the user what happens when they click on the Role's
     * icons.
     * 
     * @param indentLevel
     * @return
     */
    protected HTMLElement createRoleIconHoverLabelDiv(int indentLevel) {

        HTMLElement roleIconHoverDiv = generateDivElement(
                ITemplateConstants.ID_ROLE_GUY_DESCRIPTION,
                ITemplateConstants.CLASS_TOGGLE_OFF, indentLevel);


        // add the role icon description paragraph. It has two paragraphs. One
        // for the title and one for the description.
        HTMLElement roleIconTitle = generateSpanElement(
                ITemplateConstants.ID_ENABLE_TITLE, null, TemplatePlugin
                        .getString("role_guy_title"), indentLevel + 1);

        HTMLElement roleIconDescription = generateSpanElement(
                ITemplateConstants.ID_ENABLE_DESCRIPTION, null, TemplatePlugin
                        .getString("role_guy_description"), indentLevel + 1);

        // Create the enclosing text element: <P><SPAN>spanContent</SPAN></P>
        HTMLElement text = new FormattedHTMLElement(
                IIntroHTMLConstants.ELEMENT_PARAGRAPH, indentLevel + 1, false);
        text.addContent(roleIconTitle);
        text.addContent(roleIconDescription);

        roleIconHoverDiv.addContent(text);

        return roleIconHoverDiv;
    }



    protected HTMLElement createActiveCategoriesDiv(int indentLevel) {
        /*
         * Use span element here because we want these to all appear inline
         * instead of as block elements
         */
        HTMLElement activeRolesDiv = generateDivElement(
                ITemplateConstants.ID_ACTIVE_ROLES_TRAY, null, indentLevel);

        // create role-text span
        HTMLElement roleTextSpan = generateSpanElement(
                ITemplateConstants.ID_ROLE_TEXT_CONTENT, null, null,
                indentLevel + 1);
        activeRolesDiv.addContent(roleTextSpan);

        // create roles-curve span
        HTMLElement rolesCurveSpan = generateSpanElement(
                ITemplateConstants.ID_ROLES_CURVE, null, null, indentLevel + 1);
        activeRolesDiv.addContent(rolesCurveSpan);

        // create enabled-roles span
        HTMLElement enabledRolesSpan = createEnabledCategories(indentLevel + 1);
        activeRolesDiv.addContent(enabledRolesSpan);

        // create role-dude span
        HTMLElement selectRolesDude = createSelectRolesDude(indentLevel + 1);
        activeRolesDiv.addContent(selectRolesDude);

        return activeRolesDiv;
    }

    protected HTMLElement createEnabledCategories(int indentLevel) {
        HTMLElement enabledRolesSpan = generateSpanElement(
                ITemplateConstants.ID_ENABLED_ROLES, null, null, indentLevel);

        for (Enumeration en = availableCategories.elements(); en
                .hasMoreElements();) {
            CategoryPresentation presentation = (CategoryPresentation) en
                    .nextElement();

            if (presentation.isCategoryEnabled()) {
                // Create the link
                HTMLElement link = generateEnabledCategoryLinkTrayElement(
                        presentation.getIconPath(), presentation
                                .getCategoryName(), indentLevel + 1);
                if (link != null) {
                    // add onMouseOver attribute:
                    String mouseEventCall = showTextJSCall(presentation
                            .getCategoryName());
                    if (mouseEventCall != null)
                        link.addAttribute(ITemplateConstants.ATTR_ONMOUSEOVER,
                                mouseEventCall);

                    // add onFocus attribute:
                    mouseEventCall = showTextJSCall(presentation
                            .getCategoryName());
                    if (mouseEventCall != null)
                        link.addAttribute(ITemplateConstants.ATTR_ONFOCUS,
                                mouseEventCall);

                    // add onMouseOut/onBlur attributes:
                    mouseEventCall = showTextJSCall(ITemplateConstants.EMPTY_STRING);
                    if (mouseEventCall != null)
                        link.addAttribute(ITemplateConstants.ATTR_ONMOUSEOUT,
                                mouseEventCall);
                    if (mouseEventCall != null)
                        link.addAttribute(ITemplateConstants.ATTR_ONBLUR,
                                mouseEventCall);


                    // also add onKeyPress attribute to link. We want the
                    // flyout to also apear on a click.
                    ArrayList params = new ArrayList(1);
                    params.add(ITemplateConstants.ID_ROLE_SELECTION);
                    params.add(ITemplateConstants.ID_ROLE_GUY_DESCRIPTION);
                    mouseEventCall = createJavaScriptCall(
                            ITemplateConstants.JS_ONKEYPRESS_TOGGLE_ROLE_GUY,
                            params);
                    if (mouseEventCall != null)
                        link.addAttribute(ITemplateConstants.ATTR_ONKEYPRESS,
                                mouseEventCall);



                    enabledRolesSpan.addContent(link);



                }
            }
        }
        return enabledRolesSpan;
    }

    protected HTMLElement createSelectRolesDude(int indentLevel) {
        HTMLElement roleDude = generateSpanElement(
                ITemplateConstants.ID_ROLE_GUY,
                ITemplateConstants.CLASS_ROLE_LINK, null, indentLevel);

        HTMLElement imageElement = generateImageElement(
                ITemplateConstants.ROLE_GUY_IMG_SRC,
                ITemplateConstants.ID_ROLE_GUY_IMG,
                ITemplateConstants.ROLE_GUY_ALT_TEXT, null, indentLevel + 1);

        // add onMouseOver attribute.
        ArrayList params = new ArrayList(1);
        params.add(ITemplateConstants.ID_ROLE_GUY_DESCRIPTION);
        params.add(ITemplateConstants.ID_ROLE_SELECTION);
        String mouseEventCall = createJavaScriptCall(
                ITemplateConstants.JS_ONMOUSEOVER_ROLE_GUY, params);
        if (mouseEventCall != null)
            roleDude.addAttribute(ITemplateConstants.ATTR_ONMOUSEOVER,
                    mouseEventCall);


        // add onMouseOut attribute.
        params = new ArrayList(1);
        params.add(ITemplateConstants.ID_ROLE_GUY_DESCRIPTION);
        mouseEventCall = createJavaScriptCall(
                ITemplateConstants.JS_HIDE_ELEMENT, params);
        if (mouseEventCall != null)
            roleDude.addAttribute(ITemplateConstants.ATTR_ONMOUSEOUT,
                    mouseEventCall);

        // add onClick attribute
        params = new ArrayList(1);
        params.add(ITemplateConstants.ID_ROLE_SELECTION);
        params.add(ITemplateConstants.ID_ROLE_GUY_DESCRIPTION);
        mouseEventCall = createJavaScriptCall(
                ITemplateConstants.JS_TOGGLE_ROLE_GUY, params);
        if (mouseEventCall != null)
            roleDude.addAttribute(ITemplateConstants.ATTR_ONCLICK,
                    mouseEventCall);


        // now add onMouseOver and onMouseOut attribute to the image to handle
        // swapping the image onMouseOver
        params = new ArrayList(2);
        params.add(ITemplateConstants.ID_ROLE_GUY_IMG);
        params.add(ITemplateConstants.ROLE_GUY_HOVER_IMG_SRC);
        mouseEventCall = createJavaScriptCall(
                ITemplateConstants.JS_SWITCH_IMAGE_SRC, params);
        if (mouseEventCall != null)
            imageElement.addAttribute(ITemplateConstants.ATTR_ONMOUSEOVER,
                    mouseEventCall);

        // onMouseOut
        params = new ArrayList(2);
        params.add(ITemplateConstants.ID_ROLE_GUY_IMG);
        params.add(ITemplateConstants.ROLE_GUY_IMG_SRC);
        mouseEventCall = createJavaScriptCall(
                ITemplateConstants.JS_SWITCH_IMAGE_SRC, params);
        if (mouseEventCall != null)
            imageElement.addAttribute(ITemplateConstants.ATTR_ONMOUSEOUT,
                    mouseEventCall);

        roleDude.addContent(imageElement);
        return roleDude;
    }

}