/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Common Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/
package org.eclipse.ui.internal.intro.examples.basic002;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseTrackAdapter;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.intro.IIntroSite;
import org.eclipse.ui.part.IntroPart;

/**
 * This is a basic implementation of an Intro Part. Note: UI team will implement
 * an abstract base IntroPart class so that most APIs are already implemented.
 */
public class SampleIntroPart extends IntroPart {

    private Image image1, image2, image3;

    private Cursor handCursor;

    private IIntroSite introSite;

    private Control focusControl;

    // Images.
    String RESOURCE_ICON = "resource_persp.gif"; //$NON-NLS-1$

    String JAVA_ICON = "jperspective.gif"; //$NON-NLS-1$

    String HELP_ICON = "view.gif"; //$NON-NLS-1$

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.internal.temp.IIntroPart#init(org.eclipse.ui.internal.temp.IIntroSite)
     */
    public void init(IIntroSite site) {
        // cache the into site for its Shel.
        this.introSite = site;
    }

    public void createPartControl(Composite container) {
        // create the basic intro area. parent composite has FillLayout by
        // default.
        // create a new composite to hold all three text widgets.
        Composite outerContainer = new Composite(container, SWT.NONE);
        Color blue = container.getDisplay().getSystemColor(SWT.COLOR_BLUE);
        Color white = container.getDisplay().getSystemColor(SWT.COLOR_WHITE);
        image1 = ImageUtil.createImage(RESOURCE_ICON);
        image2 = ImageUtil.createImage(JAVA_ICON);
        image3 = ImageUtil.createImage(HELP_ICON);

        outerContainer.setBackground(white);

        // create hand cursor to be used by all CLabel items.
        handCursor = new Cursor(container.getDisplay(), SWT.CURSOR_HAND);

        // setup outer composite.
        GridLayout gridLayout = new GridLayout();
        gridLayout.numColumns = 1;
        gridLayout.marginHeight = 40;
        gridLayout.verticalSpacing = 20;
        gridLayout.makeColumnsEqualWidth = true;
        outerContainer.setLayout(gridLayout);

        final CLabel cLabel1 = new CLabel(outerContainer, SWT.SHADOW_NONE);
        focusControl = cLabel1;
        cLabel1.setText("Put Welcome into Standby");
        cLabel1.setImage(image1);
        setUpCLabel(cLabel1, blue, white);
        cLabel1.addMouseListener(new MouseAdapter() {

            public void mouseUp(MouseEvent e) {
                // REVISIT:
                // this is needed as a workaround to UI code to enable the busy
                // hourglass to appear. Without it, the hand cursor will stay.
                cLabel1.setCursor(null);
                SampleIntroPart.this.handleFirstCLabel();
            }
        });

        final CLabel cLabel2 = new CLabel(outerContainer, SWT.SHADOW_NONE);
        cLabel2.setText("Start Java Perspecxtive");
        cLabel2.setImage(image2);
        setUpCLabel(cLabel2, blue, white);
        cLabel2.addMouseListener(new MouseAdapter() {

            public void mouseUp(MouseEvent e) {
                cLabel2.setCursor(null);
                SampleIntroPart.this.handleSecondCLabel();
            }
        });

        final CLabel cLabel3 = new CLabel(outerContainer, SWT.SHADOW_NONE);
        cLabel3.setText("Read some help");
        cLabel3.setImage(image3);
        setUpCLabel(cLabel3, blue, white);
        cLabel3.addMouseListener(new MouseAdapter() {

            public void mouseUp(MouseEvent e) {
                cLabel3.setCursor(null);
                SampleIntroPart.this.handleThirdCLabel();
            }
        });

    }

    private void setUpCLabel(final CLabel label, Color foregroundColor,
            Color backgroundColor) {
        GridData gridData = new GridData();
        gridData.horizontalAlignment = GridData.BEGINNING;
        gridData.horizontalIndent = 150;
        gridData.grabExcessHorizontalSpace = true;
        label.setLayoutData(gridData);
        label.setForeground(foregroundColor);
        label.setBackground(backgroundColor);
        // setup font and make sure to dispose.
        final Font font = new Font(label.getDisplay(), "Times New Roman", 15,
            SWT.NORMAL); //$NON-NLS-1$
        label.addDisposeListener(new DisposeListener() {

            public void widgetDisposed(DisposeEvent e) {
                label.getFont().dispose();
            }
        });
        label.setFont(font);

        // now set mouse cursor to hand on entry to control.
        label.addMouseTrackListener(new MouseTrackAdapter() {

            public void mouseEnter(MouseEvent e) {
                label.setCursor(handCursor);
                Font currentFont = label.getFont();
                // REVISIT: revist later!
                Font font = new Font(label.getDisplay(), "Times New Roman", //$NON-NLS-1$
                    15, SWT.BOLD);
                label.setFont(font);
                currentFont.dispose();
                label.getParent().layout();
            }

            public void mouseExit(MouseEvent e) {
                label.setCursor(null);
                Font currentFont = label.getFont();
                // REVISIT: revist later!
                Font font = new Font(label.getDisplay(), "Times New Roman", //$NON-NLS-1$
                    15, SWT.NORMAL);
                label.setFont(font);
                currentFont.dispose();
                label.getParent().layout();
            }
        });
    }

    public void setFocus() {
        boolean value = focusControl.isVisible();
        boolean value2 = focusControl.setFocus();
        return;
    }

    private void handleFirstCLabel() {
        // For now, put IntroPart in standby mode. This make the Resource
        // perspective active.
        PlatformUI.getWorkbench().getIntroManager().setIntroStandby(
            PlatformUI.getWorkbench().getIntroManager().getIntro(), true);

    }

    private void handleSecondCLabel() {
        try {
            PlatformUI.getWorkbench().showPerspective(
                "org.eclipse.jdt.ui.JavaPerspective", //$NON-NLS-1$
                PlatformUI.getWorkbench().getActiveWorkbenchWindow());
        } catch (Exception ex) {
            // REVISIT:
            System.out.println("Failed to initialize selection listener"); //$NON-NLS-1$
        }
    }

    private void handleThirdCLabel() {
        try {
            PlatformUI.getWorkbench().getHelpSystem().displayHelp();
        } catch (Exception ex) {
            // REVISIT:
            System.out.println("Failed to initialize selection listener"); //$NON-NLS-1$
        }
    }

    /**
     * Dispose all locally created resources.
     */
    public void dispose() {
        handCursor.dispose();
        image1.dispose();
        image2.dispose();
        image3.dispose();

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.IIntroPart#init(org.eclipse.ui.intro.IIntroSite,
     *           org.eclipse.ui.IMemento)
     */
    public void init(IIntroSite site, IMemento memento)
            throws PartInitException {
        init(site);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.IIntroPart#saveState(org.eclipse.ui.IMemento)
     */
    public void saveState(IMemento memento) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.IIntroPart#standbyStateChanged(boolean)
     */
    public void standbyStateChanged(boolean standby) {

    }

}