/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Common Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/
package org.eclipse.ui.internal.intro.examples.basic002;

import java.net.*;

import org.eclipse.core.runtime.*;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.resource.*;
import org.eclipse.swt.graphics.*;

/**
 * Convenience class for Images.
 */
public final class ImageUtil {

    // plugin id
    public static final String PLUGIN_ID = "org.eclipse.ui.internal.intro.examples";
    // Image location
    public static final String ICONS_PATH = "basic002/icons/";

    /**
     * Convenience method to create an image descriptor.
     * 
     * Method assumes that images are under the "icons" directory, so don't
     * append that directory name for "imageName".
     */
    public static ImageDescriptor getImageDescriptor(String imageName) {
        try {
            URL url = Platform.find(Platform.getBundle(PLUGIN_ID), new Path(
                    ICONS_PATH + imageName));

            ImageDescriptor desc = ImageDescriptor.createFromURL(url);
            return desc;
        } catch (Exception e) {
            return ImageDescriptor.getMissingImageDescriptor();
        }

    }

    /**
     * Convenience method to create an image.
     * 
     * Method assumes that images are under the "icons" directory, so don't
     * append that directory name for "imageName".
     */
    public static Image createImage(String imageName) {
        try {
            ImageDescriptor imageDsc = getImageDescriptor(imageName);
            return imageDsc.createImage();
        } catch (Exception e) {
            return ImageDescriptor.getMissingImageDescriptor().createImage();
        }

    }
}