/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ui.internal.intro.examples.basic001;

import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.part.*;

/**
 * This is a basic implementation of an Intro Part.
 */
public class FocusIntroPart extends IntroPart {

    private Label label;

    private Button button;

    public void createPartControl(Composite container) {
        // create the basic intro area. parent composite has FillLayout by
        // default.create a new composite to hold all three text widgets.
        Composite outerContainer = new Composite(container, SWT.NONE);
        // setup outer composite.
        GridLayout gridLayout = new GridLayout();
        outerContainer.setLayout(gridLayout);
        label = new Label(outerContainer, SWT.NULL);
        label.setText("Testing focus.");
        button = new Button(outerContainer, SWT.NULL);
        button.setText("Testing button.");

    }

    public void setFocus() {
        button.setFocus();
        return;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.IIntroPart#standbyStateChanged(boolean)
     */
    public void standbyStateChanged(boolean standby) {
        System.out.println("test");

    }

}