/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Common Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/
package org.eclipse.ui.intro.examples.static001;

import java.util.*;

import org.eclipse.ui.*;
import org.eclipse.ui.actions.*;
import org.eclipse.ui.intro.*;
import org.eclipse.ui.intro.config.*;

/**
 * An Intro Action that knows how to run an action with the passed "actionId".
 * The action is constructed as follows:
 * 
 *  
 */
public class RunActionFromId implements IIntroAction {

    public void run(IIntroSite site, Properties params) {
        final String actionID = params.getProperty("actionId");
        if (actionID != null) {
            try {
                // Get the correct action factory and create an action in the
                // active workbench window
                IWorkbenchWindow window = PlatformUI.getWorkbench()
                        .getActiveWorkbenchWindow();
                ActionFactory.IWorkbenchAction action = null;
                if (actionID.equals("preferences"))
                    action = ActionFactory.PREFERENCES.create(window);
                else if (actionID.equals("import"))
                    action = ActionFactory.IMPORT.create(window);
                else if (actionID.equals("export"))
                    action = ActionFactory.EXPORT.create(window);

                if (action != null) {
                    action.run();
                    action.dispose();
                }

            } catch (Exception e) { // log err }
            }
        }
    }

}