/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Common Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/

package org.eclipse.ui.intro.examples.dynamic002;

import java.util.Properties;

import org.eclipse.ui.internal.intro.impl.model.IntroURL;
import org.eclipse.ui.internal.intro.impl.model.IntroURLParser;
import org.eclipse.ui.intro.IIntroSite;
import org.eclipse.ui.intro.config.IIntroAction;

/**
 * A sample Intro action that shows a page with the passed id. This action
 * demonstrates how to invoke Intro URL actions programatically. An action
 * shortcut called MyShowPage is defined to run this action.
 */
public class MyShowPageAction implements IIntroAction {

    public void run(IIntroSite site, Properties params) {
        String id = params.getProperty("id");
        if (id == null)
            return;

        String urlActionString = "http://org.eclipse.ui.intro/showPage?"
                + "id=" + id;
        IntroURLParser parser = new IntroURLParser(urlActionString);
        IntroURL urlAction = parser.getIntroURL();
        urlAction.execute();
    }

}