/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Common Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/
package org.eclipse.ui.intro.examples.basic001;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.IntroPart;

/**
 * This is a basic implementation of an Intro Part.
 */
public class HelloWorldIntroPart extends IntroPart {

    private Label label;
    private Button button;

    public void createPartControl(Composite container) {
        // create the basic intro area. parent composite has FillLayout by
        // default. Create a new composite to hold all three text widgets.
        Composite outerContainer = new Composite(container, SWT.NONE);
        // setup outer composite.
        GridLayout gridLayout = new GridLayout();
        outerContainer.setLayout(gridLayout);
        outerContainer.setBackground(outerContainer.getDisplay()
            .getSystemColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
        label = new Label(outerContainer, SWT.CENTER);
        label.setText("WELCOME TO ECLIPSE");
        GridData gd = new GridData(GridData.GRAB_HORIZONTAL
                | GridData.GRAB_VERTICAL);
        gd.horizontalAlignment = GridData.CENTER;
        gd.verticalAlignment = GridData.CENTER;
        label.setLayoutData(gd);
        label.setBackground(outerContainer.getDisplay().getSystemColor(
            SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
    }

    public void setFocus() {
        this.getIntroSite().getShell().setFocus();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.ui.intro.IIntroPart#standbyStateChanged(boolean)
     */
    public void standbyStateChanged(boolean standby) {
    }



}