package org.eclipse.jface.action;

/*
 * Licensed Materials - Property of IBM,
 * WebSphere Studio Workbench
 * (c) Copyright IBM Corp 2001
 */
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Image;

/**
 * The <code>IStatusLineManager</code> interface provides protocol
 * for displaying messages on a status line, for monitoring progress,
 * and for managing contributions to the status line.
 * <p>
 * This package also provides a concrete status line manager implementation,
 * {@link StatusLineManager <code>StatusLineManager</code>}.
 * </p>
 */
public interface IStatusLineManager extends IContributionManager {
/**
 * Returns a progress monitor which reports progress
 * in the status line.
 *
 * @return the progress monitor
 */
public IProgressMonitor getProgressMonitor();
/**
 * Returns whether the cancel button on the status line's progress monitor
 * is enabled.
 *
 * @return <code>true</code> if the cancel button is enabled, or <code>false</code> if not
 */
public boolean isCancelEnabled();
/**
 * Sets whether the cancel button on the status line's progress monitor
 * is enabled.
 *
 * @param enabled<code>true</code> if the cancel button is enabled, or <code>false</code> if not
 */
public void setCancelEnabled(boolean enabled);
/**
 * Sets the error message text to be displayed on the status line.
 * The image on the status line is cleared.
 *
 * @param message the error message, or <code>null</code> for no message
 */
public void setErrorMessage(String message);
/**
 * Sets the image and error message to be displayed on the status line.
 *
 * @param image the image to use, or <code>null</code> for no image
 * @param message the error message, or <code>null</code> for no message
 */
public void setErrorMessage(Image image, String message);
/**
 * Sets the message text to be displayed on the status line.
 * The image on the status line is cleared.
 *
 * @param message the message, or <code>null</code> for no message
 */
public void setMessage(String message);
/**
 * Sets the image and message to be displayed on the status line.
 *
 * @param image the image to use, or <code>null</code> for no image
 * @param message the message, or <code>null</code> for no message
 */
public void setMessage(Image image, String message);
}
