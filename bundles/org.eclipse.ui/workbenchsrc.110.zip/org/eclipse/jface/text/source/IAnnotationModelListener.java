package org.eclipse.jface.text.source;

public interface IAnnotationModelListener {

	/**
	 * Called if a model change occurred on the given model.
	 *
	 * @param model the changed annotation model
	 */
	void modelChanged(IAnnotationModel model);
}