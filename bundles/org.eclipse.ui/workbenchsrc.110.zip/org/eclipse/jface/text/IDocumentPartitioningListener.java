package org.eclipse.jface.text;

public interface IDocumentPartitioningListener {
	
	/**
	 * The partitioning of the given document changed.
	 *
	 * @param document the document whose partitioning changed
	 *
	 * @see IDocument#addDocumentPartitioningListener
	 */
	void documentPartitioningChanged(IDocument document);
}