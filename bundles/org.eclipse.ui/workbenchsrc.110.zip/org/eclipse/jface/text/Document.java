package org.eclipse.jface.text;

public class Document extends AbstractDocument {
	
	
	/**
	 * Creates a new empty document.
	 */
	public Document() {
		super();
		setTextStore(new GapTextStore(50, 300));
		setLineTracker(new DefaultLineTracker());
		completeInitialization();
	}
	
	/**
	 * Creates a new document with the given initial content.
	 *
	 * @param initialContent the document's initial content
	 */
	public Document(String initialContent) {
		super();
		setTextStore(new GapTextStore(50, 300));
		setLineTracker(new DefaultLineTracker());	
		getStore().set(initialContent);
		getTracker().set(initialContent);
		completeInitialization();
	}
}