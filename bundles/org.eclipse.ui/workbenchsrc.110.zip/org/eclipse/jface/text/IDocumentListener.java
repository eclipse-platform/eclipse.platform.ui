package org.eclipse.jface.text;

public interface IDocumentListener {
	
	
	/**
	 * The manipulation described by the document event will be performed.
	 * 
	 * @param event the document event describing the document change 
	 */
	void documentAboutToBeChanged(DocumentEvent event);

	/**
	 * The manipulation described by the document event has been performed.
	 *
	 * @param event the document event describing the document change
	 */
	void documentChanged(DocumentEvent event);
}