package org.eclipse.jface.text;

public interface IRegion {
		
	/**
	 * Returns the length of the region.
	 *
	 * @return the length of the region
	 */
	int getLength();
	
	/**
	 * Returns the offset of the region.
	 *
	 * @return the offset of the region
	 */
	int getOffset();
}