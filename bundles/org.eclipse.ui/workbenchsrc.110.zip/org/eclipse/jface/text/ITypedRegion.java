package org.eclipse.jface.text;

public interface ITypedRegion extends IRegion {
	
	/**
	 * Returns the content type of the region.
	 *
	 * @return the content type of the region
	 */
	String getType();
}