package org.eclipse.jface.text;

public class TextEvent {
	
	/** Start offset of the change */ 
	private int fOffset;
	/** The length of the change */
	private int fLength;
	/** Inserted text */
	private String fText;
	/** Replaced text */
	private String fReplacedText;
	/** The original document event, may by null */
	private DocumentEvent fDocumentEvent;
	
	/**
	 * Creates a new <code>TextEvent</code> based on the specification.
	 */
	protected TextEvent(int offset, int length, String text, String replacedText, DocumentEvent event) {
		fOffset= offset;
		fLength= length;
		fText= text;
		fReplacedText= replacedText;
		fDocumentEvent= event;
	}
		
	/**
	 * Returns the offset of the event.
	 *
	 * @return the offset of the event
	 */
	public int getOffset() {
		return fOffset;
	}
		
	/**
	 * Returns the length of the event.
	 *
	 * @return the length of the event
	 */
	public int getLength() {
		return fLength;
	}
	
	/**
	 * Returns the text of the event.
	 *
	 * @return the text of the event
	 */
	public String getText() {
		return fText;
	}
	
	/**
	 * Returns the text replaced by this event.
	 *
	 * @return the text replaced by this event
	 */
	public String getReplacedText() {
		return fReplacedText;
	}
	
	/**
	 * Returns the corresponding document event that caused the viewer change
	 *
	 * @return the corresponding document event, <code>null</code> if a visual change only
	 */
	public DocumentEvent getDocumentEvent() {
		return fDocumentEvent;
	}
}