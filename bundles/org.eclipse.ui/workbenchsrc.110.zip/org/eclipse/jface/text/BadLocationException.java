package org.eclipse.jface.text;

public class BadLocationException extends Exception {
	
	/**
	 * Creates a new bad location exception.
	 */
	public BadLocationException() {
		super();
	}
	
	/**
	 * Creates a new bad location exception.
	 *
	 * @param message the exception message
	 */
	public BadLocationException(String message) {
		super(message);
	}
}