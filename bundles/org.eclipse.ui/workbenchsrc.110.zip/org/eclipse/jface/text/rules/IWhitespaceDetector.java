package org.eclipse.jface.text.rules;

public interface IWhitespaceDetector {

	/**
	 * Returns whether the specified character is whitespace.
	 */
	boolean isWhitespace(char c);
}