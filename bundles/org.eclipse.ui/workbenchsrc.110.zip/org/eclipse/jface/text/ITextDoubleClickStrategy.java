package org.eclipse.jface.text;

public interface ITextDoubleClickStrategy {

	/**
	 * The mouse has been double clicked on the given text viewer.
	 *
	 * @param viewer the viewer into which has been double clicked
	 */
	void doubleClicked(ITextViewer viewer);
}