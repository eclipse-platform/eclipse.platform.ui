package org.eclipse.jface.text;

public interface IViewportListener {
	
	/**
	 * Informs about viewport changes. The given vertical position
	 * is the new vertical scrolling offset measured in pixels.
	 */
	void viewportChanged(int verticalOffset);
}