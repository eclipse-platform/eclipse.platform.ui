package org.eclipse.jface.text;

public interface IAutoIndentStrategy {
	
	/**
	 * Allows the strategy to manipulate the document command.
	 *
	 * @param document the document that will be changed
	 * @param command the document command describing the indented change
	 */
	void customizeDocumentCommand(IDocument document, DocumentCommand command);	
}