package org.eclipse.jface.text;

public interface ITextInputListener {
	
	/**
	 * Called before the input document is replaced.
	 * 
	 * @param oldInput the text viewer's previous input document
	 * @param newInput the text viewer's new input document
	 */
	void inputDocumentAboutToBeChanged(IDocument oldInput, IDocument newInput);
	
	/**
	 * Called after the input document has been replaced.
	 * 
	 * @param oldInput the text viewer's previous input document
	 * @param newInput the text viewer's new input document
	 */
	void inputDocumentChanged(IDocument oldInput, IDocument newInput);
}