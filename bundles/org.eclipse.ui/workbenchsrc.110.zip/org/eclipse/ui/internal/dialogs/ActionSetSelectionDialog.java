package org.eclipse.ui.internal.dialogs;

/*
 * Licensed Materials - Property of IBM,
 * WebSphere Studio Workbench
 * (c) Copyright IBM Corp 2000
 */
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.layout.*;
import org.eclipse.ui.internal.registry.*;
import org.eclipse.ui.internal.*;
import org.eclipse.ui.help.WorkbenchHelp;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.model.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Dialog to display the available action sets, and
 * solicits a list of selections from the user.
 */
public class ActionSetSelectionDialog extends Dialog {
	// input data.
	private Perspective perspective;
	private ActionSetDialogInput input;
	
	// widgets.
	private CheckboxTreeViewer actionSetViewer;
	private Label actionLabel;
	private TableViewer actionViewer;
	
	// sizing constants
	private final static int SIZING_SELECTION_WIDGET_HEIGHT = 190;
	private final static int SIZING_SELECTION_WIDGET_WIDTH = 160;
/**
 * Creates an action set selection dialog.
 */
public ActionSetSelectionDialog(
		Shell parentShell,
		Perspective persp)
{
	super(parentShell);
	perspective = persp;
	input = new ActionSetDialogInput();
}
/**
 * Visually checks the previously-specified elements.
 */
private void checkInitialSelections() {
	IActionSetDescriptor [] actionSets = perspective.getActionSets();
	if (actionSets != null) {
		for (int i = 0; i < actionSets.length; i++)
			actionSetViewer.setChecked(actionSets[i],true);
	}

	ArrayList actions = perspective.getShowViewActions();
	if (actions != null) {
		for (int nX = 0; nX < actions.size(); nX ++) {
			String id = (String)actions.get(nX);
			actionSetViewer.setChecked(input.getViewActionSet(id), true);
		}
	}

	actions = perspective.getPerspectiveActions();
	if (actions != null) {
		for (int nX = 0; nX < actions.size(); nX ++) {
			String id = (String)actions.get(nX);
			actionSetViewer.setChecked(input.getPerspectiveActionSet(id), true);
		}
	}
	
	actions = perspective.getNewWizardActions();
	if (actions != null) {
		for (int nX = 0; nX < actions.size(); nX ++) {
			String id = (String)actions.get(nX);
			actionSetViewer.setChecked(input.getWizardActionSet(id), true);
		}
	}

	Object[] categories = input.getCategories();
	for (int i = 0; i < categories.length; i++) {
		ActionSetCategory cat = (ActionSetCategory)categories[i];
		ArrayList sets = cat.getActionSets();
		if (sets != null && sets.size() > 0) {
			boolean baseChildState = actionSetViewer.getChecked(sets.get(0));
			updateCategoryState(cat, baseChildState);
		}
	}
}
/* (non-Javadoc)
 * Method declared in Window.
 */
protected void configureShell(Shell shell) {
	super.configureShell(shell);
	shell.setText("Customize Perspective");
	WorkbenchHelp.setHelp(shell, new Object[] {IHelpContextIds.ACTION_SET_SELECTION_DIALOG});
}
/* (non-Javadoc)
 * Method declared on Dialog.
 */
protected Control createDialogArea(Composite parent) {
	Composite composite = (Composite)super.createDialogArea(parent);
	GridLayout layout = (GridLayout)composite.getLayout();
	layout.numColumns = 2;
	GridData data;

	// description
	Label descLabel = new Label(composite, SWT.WRAP);
	descLabel.setText("Select the visible action sets for the current perspective (" + perspective.getDesc().getLabel() + ").");
	descLabel.setFont(parent.getFont());
	data = new GridData(GridData.FILL_HORIZONTAL);
	data.horizontalSpan = 2;
	descLabel.setLayoutData(data);
	
	// Setup the action set list selection...
	// ...first a composite group
	Composite actionSetGroup = new Composite(composite, SWT.NONE);
	layout = new GridLayout();
	layout.marginHeight = 0;
	layout.marginWidth = 0;
	actionSetGroup.setLayout(layout);
	data = new GridData(GridData.FILL_VERTICAL);
	actionSetGroup.setLayoutData(data);
	
	// ...second the label
	Label selectionLabel = new Label(actionSetGroup,SWT.NONE);
	selectionLabel.setText("Available Action Sets:");
	selectionLabel.setFont(parent.getFont());

	// ...third the checkbox list
	actionSetViewer = new CheckboxTreeViewer(actionSetGroup, SWT.BORDER);
	data = new GridData(GridData.FILL_BOTH);
	data.heightHint = SIZING_SELECTION_WIDGET_HEIGHT;
	data.widthHint = SIZING_SELECTION_WIDGET_WIDTH;
	actionSetViewer.getTree().setLayoutData(data);
	actionSetViewer.setLabelProvider(new ActionSetLabelProvider());
	actionSetViewer.setContentProvider(new ActionSetContentProvider());
	actionSetViewer.setInput(input);
	actionSetViewer.setSorter(new ActionSetSorter());
	actionSetViewer.addSelectionChangedListener(
		new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				IStructuredSelection sel = (IStructuredSelection)event.getSelection();
				IActionSetDescriptor actionSet = null;
				if (sel.getFirstElement() instanceof IActionSetDescriptor)
					actionSet = (IActionSetDescriptor)sel.getFirstElement();
				if (actionSet != actionViewer.getInput()) {
					if (actionSet == null)
						actionLabel.setText("");
					else
						actionLabel.setText(actionSet.getLabel() + ":");
					actionLabel.getParent().layout();
					actionViewer.setInput(actionSet);
				}
			}
		});
	actionSetViewer.addCheckStateListener(new ICheckStateListener() {
		public void checkStateChanged(CheckStateChangedEvent event) {
			handleActionSetChecked(event);
		}
	});

	// Setup the action list for the action set selected...
	// ...first a composite group
	Composite actionGroup = new Composite(composite, SWT.NONE);
	layout = new GridLayout();
	layout.marginHeight = 0;
	layout.marginWidth = 0;
	actionGroup.setLayout(layout);
	data = new GridData(GridData.FILL_VERTICAL);
	actionGroup.setLayoutData(data);
	
	// ...second the label
	actionLabel = new Label(actionGroup, SWT.NONE);
	actionLabel.setText("");

	// ...third the list of actions
	actionViewer = new TableViewer(actionGroup, SWT.BORDER);
	data = new GridData(GridData.FILL_BOTH);
	data.heightHint = SIZING_SELECTION_WIDGET_HEIGHT;
	data.widthHint = SIZING_SELECTION_WIDGET_WIDTH;
	actionViewer.getTable().setLayoutData(data);
	actionViewer.setLabelProvider(new WorkbenchLabelProvider());
	actionViewer.setContentProvider(new WorkbenchContentProvider());
	actionViewer.setSorter(new WorkbenchViewerSorter());
	actionViewer.getTable().setEnabled(false);
	actionViewer.getTable().setBackground(WorkbenchColors.getSystemColor(SWT.COLOR_WIDGET_BACKGROUND));
	TableLayout tableLayout = new TableLayout();
	tableLayout.addColumnData(new ColumnWeightData(100));
	actionViewer.getTable().setLayout(tableLayout);
	TableColumn tc = new TableColumn(actionViewer.getTable(), SWT.NONE, 0);
	tc.setResizable(false);

	
	// initialize page
	checkInitialSelections();

	return composite;
}
/**
 * Checked event handler for the action set tree.
 */
private void handleActionSetChecked(CheckStateChangedEvent event) {
	// On action set category check/uncheck. Category can be
	// in three states:
	//		1) all children uncheck -> category uncheck
	//		2) some children check  -> category check & gray
	//		3) all children check   -> category check 
	if (event.getElement() instanceof ActionSetCategory) {
		// On check, check all its children also
		if (event.getChecked()) {
			actionSetViewer.setSubtreeChecked(event.getElement(), true);
			return;
		}
		// On uncheck & gray, remain check but ungray
		// and check all its children
		if (actionSetViewer.getGrayed(event.getElement())) {
			actionSetViewer.setChecked(event.getElement(), true);
			actionSetViewer.setGrayed(event.getElement(), false);
			actionSetViewer.setSubtreeChecked(event.getElement(), true);
			return;
		}
		// On uncheck & not gray, uncheck all its children
		actionSetViewer.setSubtreeChecked(event.getElement(), false);
		return;
	}

	// On action set check/uncheck
	if (event.getElement() instanceof IActionSetDescriptor) {
		IActionSetDescriptor desc = (IActionSetDescriptor)event.getElement();
		ActionSetCategory cat = input.findCategory(desc.getCategory());
		updateCategoryState(cat, event.getChecked());
		return;
	}
}
/**
 * The <code>ActionSetSelectionDialog</code> implementation of this 
 * <code>Dialog</code> method builds a list of the selected elements for later
 * retrieval by the client and closes this dialog.
 */
protected void okPressed() {
	// Prepare result arrays.
	ArrayList actionSets = new ArrayList();
	ArrayList viewActions = new ArrayList();
	ArrayList perspActions = new ArrayList();
	ArrayList wizardActions = new ArrayList();

	// Fill result arrays.
	Object[] selected = actionSetViewer.getCheckedElements();
	for (int nX = 0; nX < selected.length; nX ++) {
		Object obj = selected[nX];
		if (obj instanceof FakeViewActionSet) {
			viewActions.add(((FakeViewActionSet)obj).getView().getID());
		} else if (obj instanceof FakePerspectiveActionSet) {
			perspActions.add(((FakePerspectiveActionSet)obj).getPerspective().getId());
		} else if (obj instanceof FakeWizardActionSet) {
			wizardActions.add(((FakeWizardActionSet)obj).getWizard().getID());
		} else if (obj instanceof ActionSetDescriptor) {
			actionSets.add(obj);
		}
	}

	perspective.setShowViewActions(viewActions);
	perspective.setPerspectiveActions(perspActions);
	perspective.setNewWizardActions(wizardActions);

	IActionSetDescriptor [] actionSetArray = new IActionSetDescriptor[actionSets.size()];
	actionSetArray = (IActionSetDescriptor [])actionSets.toArray(actionSetArray);
	perspective.setActionSets(actionSetArray);
	
	super.okPressed();
}
/**
 * Update the check and gray state of a category
 * Category can be in three states:
 * 	1) all children uncheck -> category uncheck
 * 	2) some children check  -> category check & gray
 * 	3) all children check   -> category check
 */
private void updateCategoryState(ActionSetCategory cat, boolean baseChildState) {
	// Check if all the action sets of the category are all
	// in the same state at the action set of the event
	boolean allSameState = true;
	Iterator enum = cat.getActionSets().iterator();
	while (enum.hasNext()) {
		if (actionSetViewer.getChecked(enum.next()) != baseChildState) {
			allSameState = false;
			break;
		}
	}

	// On all the same state, ungray the category and
	// set the category's state to be the same
	if (allSameState) {
		actionSetViewer.setGrayed(cat, false);
		actionSetViewer.setChecked(cat, baseChildState);
		return;
	}

	// On all different state, gray the category and
	// check the category
	actionSetViewer.setGrayed(cat, true);
	actionSetViewer.setChecked(cat, true);
	return;
}
}
