package org.eclipse.ui.internal.misc;

/*
 * Licensed Materials - Property of IBM,
 * WebSphere Studio Workbench
 * (c) Copyright IBM Corp 2000
 */
import java.util.Map;
import java.util.HashMap;

/**
 * A Stopwatch is used to measure the time elapsed during 
 * an operation.  To do this create a stopwatch before the
 * operation is executed and call stop() when the operation 
 * afterwards.  The elapsed time will be printed.
 *
 * A Stopwatch can also be used to measure an interval time.  To
 * do this create a stopwatch and call printInterval after
 * every important interval.  The resetInterval method can also
 * be used to start a new interval.
 *
 * A Stopwatch can also be registered for global access.  To 
 * do this create a stopwatch and call register.  From this point 
 * on a handle to the stopwatch can be retrieved by calling
 * Stopwatch.getStopwatch("name").  The stopwatch should be
 * unregistered when no longer needed.
 */
public class Stopwatch {
	private long startTime;
	private long lastTime;
	private String name;
	private static Map registry;
/**
 * Construct a new Stopwatch and start it.
 * To reset the watch at a later time just call start() again.
 */
public Stopwatch(String name) {
	this.name = name;
	start();
}
/**
 * Get a stopwatch from the registry.
 */
static public Stopwatch getStopwatch(String name) {
	if (registry != null)
		return (Stopwatch)registry.get(name);
	else
		return null;
}
/**
 * Print the elapsed time since start(), printInterval(), or 
 * resetInterval() was last called.
 */
public void printInterval(String hint) {
	long time = System.currentTimeMillis() - lastTime;
	System.out.println(name + " '" + hint + "' took " + time + " ms");
	lastTime = System.currentTimeMillis();
}
/**
 * Print the current elapsed time.
 */
public void printTime() {
	long time = System.currentTimeMillis() - startTime;
	System.out.print(name + " is now " + time + " ms");
}
/**
 * Add this stopwatch to the registry.
 */
public void register() {
	if (registry == null)
		registry = new HashMap(2);
	registry.put(name, this);
}
/**
 * Reset the interval timer.
 */
public void resetInterval() {
	lastTime = System.currentTimeMillis();
}
/**
 * Start the watch.
 */
public void start() {
	startTime = lastTime = System.currentTimeMillis();
	System.out.println(name + " started");
}
/**
 * Stop the watch and print the elapsed time.
 */
public void stop() {
	long time = System.currentTimeMillis() - startTime;
	System.out.println(name + " finished in " + time + " ms");
}
/**
 * Remove this stopwatch from the registry.
 */
public void unregister() {
	if (registry != null)
		registry.remove(name);
}
}
