package org.eclipse.ui.internal;

/*
 * Licensed Materials - Property of IBM,
 * WebSphere Studio Workbench
 * (c) Copyright IBM Corp 2000
 */

import java.util.*;
import java.util.List;
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.*;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.*;
import org.eclipse.ui.internal.*;
import org.eclipse.ui.internal.misc.UIHackFinder;

/**
 * Represents the area set aside for editor workbooks.
 * This container only accepts EditorWorkbook and PartSash
 * as layout parts.
 *
 * Note no views are allowed within this container.
 */
public class EditorArea extends PartSashContainer {
	private static final String DEFAULT_WORKBOOK_ID = "DefaultEditorWorkbook";
	private IPartDropListener partDropListener;
	private ArrayList editorWorkbooks = new ArrayList(3);
	private EditorWorkbook activeEditorWorkbook;
public EditorArea(String editorId, IPartDropListener listener, Listener mouseDownListener) {
	super(editorId);

	this.partDropListener = listener;
	this.mouseDownListener = mouseDownListener;
	createDefaultWorkbook();
}
/**
 * Add an editor to the active workbook.
 */
public void addEditor(EditorPane part) {
	EditorWorkbook workbook = getActiveWorkbook();
	workbook.add(part);
}
/**
 * Notification that a child layout part has been
 * added to the container. Subclasses may override
 * this method to perform any container specific
 * work.
 */
protected void childAdded(LayoutPart child) {
	if (child instanceof EditorWorkbook)
		editorWorkbooks.add(child);
}
/**
 * Notification that a child layout part has been
 * removed from the container. Subclasses may override
 * this method to perform any container specific
 * work.
 */
protected void childRemoved(LayoutPart child) {
	if (child instanceof EditorWorkbook) {
		editorWorkbooks.remove(child);
		if (activeEditorWorkbook == child)
			setActiveWorkbook(null, false);
	}
}
protected EditorWorkbook createDefaultWorkbook() {
	EditorWorkbook newWorkbook = new EditorWorkbook(this);
	newWorkbook.setID(DEFAULT_WORKBOOK_ID);
	add(newWorkbook);
	return newWorkbook;
}
/**
 * Subclasses override this method to specify
 * the composite to use to parent all children
 * layout parts it contains.
 */
protected Composite createParent(Composite parentWidget) {
	return new Composite(parentWidget, SWT.NONE);
}
/**
 * Dispose of the editor area.
 */
public void dispose() {
	// Free editor workbooks.
	Iterator iter = editorWorkbooks.iterator();
	while (iter.hasNext()) {
		EditorWorkbook wb = (EditorWorkbook)iter.next();
		wb.dispose();
	}
	editorWorkbooks.clear();
	editorWorkbooks = null;

	// Free rest.
	super.dispose();
}
/**
 * Subclasses override this method to dispose
 * of any swt resources created during createParent.
 */
protected void disposeParent() {
	this.parent.dispose();
}
/**
 * Return the editor workbook which is active.
 */
public EditorWorkbook getActiveWorkbook() {
	if (activeEditorWorkbook == null) {
		if (editorWorkbooks.size() < 1)
			setActiveWorkbook(createDefaultWorkbook(), false);
		else 
			setActiveWorkbook((EditorWorkbook)editorWorkbooks.get(0), false);
	}

	return activeEditorWorkbook;
}
/**
 * Return the editor workbook id which is active.
 */
public String getActiveWorkbookID() {
	return getActiveWorkbook().getID();
}
/**
 * Return the all the editor workbooks.
 */
public ArrayList getEditorWorkbooks() {
	return (ArrayList)editorWorkbooks.clone();
}
/**
 * Return the interested listener of d&d events.
 */
public IPartDropListener getPartDropListener() {
	return partDropListener;
}
/**
 * Return true is the workbook specified
 * is the active one.
 */
protected boolean isActiveWorkbook(EditorWorkbook workbook) {
	return activeEditorWorkbook == workbook;
}
/**
 * Remove all the editors
 */
public void removeAllEditors() {
	EditorWorkbook currentWorkbook = getActiveWorkbook();

	// Iterate over a copy so the original can be modified.	
	Iterator workbooks = ((ArrayList)editorWorkbooks.clone()).iterator();
	while (workbooks.hasNext()) {
		EditorWorkbook workbook = (EditorWorkbook)workbooks.next();
		workbook.removeAll();
		if (workbook != currentWorkbook) {
			remove(workbook);
			workbook.dispose();
		}
	}
}
/**
 * Remove an editor from its' workbook.
 */
public void removeEditor(EditorPane pane) {
	EditorWorkbook workbook = pane.getWorkbook();
	if (workbook == null)
		return;
	workbook.remove(pane);

	// remove the editor workbook if empty and
	// there are other workbooks
	if (workbook.getItemCount() < 1 && editorWorkbooks.size() > 1) {
		remove(workbook);
		workbook.dispose();
	}
}
/**
 * @see IPersistablePart
 */
public void restoreState(IMemento memento) {
	// Remove the default editor workbook that is
	// initialy created with the editor area.
	if (children != null) {
		EditorWorkbook defaultWorkbook = null;
		for (int i = 0; i < children.size(); i++) {
			LayoutPart child = (LayoutPart)children.get(i);
			if (child.getID() == DEFAULT_WORKBOOK_ID) {
				defaultWorkbook = (EditorWorkbook)child;
				if (defaultWorkbook.getItemCount() > 0)
					defaultWorkbook = null;
			}
		}
		if (defaultWorkbook != null)
			remove(defaultWorkbook);
	}

	// Restore the relationship/layout
	IMemento [] infos = memento.getChildren(IWorkbenchConstants.TAG_INFO);
	Map mapIDtoPart = new HashMap(infos.length);

	for (int i = 0; i < infos.length; i ++) {
		// Get the info details.
		IMemento childMem = infos[i];
		String partID = childMem.getString(IWorkbenchConstants.TAG_PART);
		String relativeID = childMem.getString(IWorkbenchConstants.TAG_RELATIVE);
		int relationship = 0;
		float ratio = 0.0f;
		if (relativeID != null) {
			relationship = childMem.getInteger(IWorkbenchConstants.TAG_RELATIONSHIP).intValue();
			ratio = childMem.getFloat(IWorkbenchConstants.TAG_RATIO).floatValue();
		}

		// Create the part.
		EditorWorkbook workbook = new EditorWorkbook(this);
		workbook.setID(partID);
		UIHackFinder.fixFuture(); // 1FUN70C: ITPUI:WIN - Shouldn't set Container when not active
		workbook.setContainer(this);
		
		// Add the part to the layout
		if (relativeID == null) {
			add(workbook);
		} else {
			LayoutPart refPart = (LayoutPart)mapIDtoPart.get(relativeID);
			if (refPart != null) {
				add(workbook, relationship, ratio, refPart);	
			} else {
				WorkbenchPlugin.log("Unable to find part for ID: " + relativeID);
			}
		}
		mapIDtoPart.put(partID, workbook);
	}
}
/**
 * @see IPersistablePart
 */
public void saveState(IMemento memento) {
	RelationshipInfo[] relationships = computeRelation();
	for (int i = 0; i < relationships.length; i ++) {
		// Save the relationship info ..
		//		private LayoutPart part;
		// 		private int relationship;
		// 		private float ratio;
		// 		private LayoutPart relative;
		RelationshipInfo info = relationships[i];
		IMemento childMem = memento.createChild(IWorkbenchConstants.TAG_INFO);
		childMem.putString(IWorkbenchConstants.TAG_PART, info.part.getID());
		if (info.relative != null) {
			childMem.putString(IWorkbenchConstants.TAG_RELATIVE, info.relative.getID());
			childMem.putInteger(IWorkbenchConstants.TAG_RELATIONSHIP, info.relationship);
			childMem.putFloat(IWorkbenchConstants.TAG_RATIO, info.ratio);
		}
	}
}
/**
 * Set the editor workbook which is active.
 */
public void setActiveWorkbook(EditorWorkbook newWorkbook, boolean hasFocus) {
	EditorWorkbook oldWorkbook = activeEditorWorkbook;
	activeEditorWorkbook = newWorkbook;
	
	if (oldWorkbook != null && oldWorkbook != newWorkbook)
		oldWorkbook.tabFocusHide();

	if (newWorkbook != null)
		newWorkbook.tabFocusShow(hasFocus);
}
/**
 * Set the editor workbook which is active.
 */
public void setActiveWorkbookFromID(String id) {
	for (int i = 0; i < editorWorkbooks.size(); i++) {
		EditorWorkbook workbook = (EditorWorkbook) editorWorkbooks.get(i);
		if (workbook.getID().equals(id))
			setActiveWorkbook(workbook, false);
	}
}
}
