package org.eclipse.ui.actions;

/*
 * Licensed Materials - Property of IBM,
 * WebSphere Studio Workbench
 * (c) Copyright IBM Corp 2000
 */
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.ui.*;
import org.eclipse.ui.help.WorkbenchHelp;
import org.eclipse.ui.internal.IHelpContextIds;
import org.eclipse.ui.internal.WorkbenchPlugin;
import org.eclipse.ui.internal.misc.Assert;
import org.eclipse.ui.internal.dialogs.DialogUtil;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import java.util.Iterator;

/**
 * Standard action for opening a system editor on the currently selected file 
 * resource.
 * <p>
 * This class may be instantiated; it is not intended to be subclassed.
 * </p>
 */
public class OpenSystemEditorAction extends SelectionListenerAction  {

	/**
	 * The id of this action.
	 */
	public static final String ID = PlatformUI.PLUGIN_ID + ".OpenSystemEditorAction";
	
	/**
	 * The workbench page to open the editor in.
	 */
	private IWorkbenchPage workbenchPage;
/**
 * Creates a new action that will open system editors on the then-selected file 
 * resources.
 *
 * @param page the workbench page in which to open the editor
 */
public OpenSystemEditorAction(IWorkbenchPage page) {
	super("&System Editor");
	setToolTipText("Edit the file with the system editor");
	setId(ID);
	WorkbenchHelp.setHelp(this, new Object[] {IHelpContextIds.OPEN_SYSTEM_EDITOR_ACTION});
	Assert.isNotNull(page);
	this.workbenchPage = page;
}
/**
 * Return the workbench page to open the editor in.
 *
 * @return the workbench page to open the editor in
 */
IWorkbenchPage getWorkbenchPage() {
	return workbenchPage;
}
/**
 * Opens a system editor on the given file resource.
 *
 * @param file the file resource
 */
void openFile(IFile file) {
	if (getWorkbenchPage() == null) {
		IStatus status = new Status(IStatus.ERROR, WorkbenchPlugin.PI_WORKBENCH, 1, "Workbench page must be supplied to OpenSystemEditorAction", null);
		WorkbenchPlugin.log("Error in OpenSystemEditorAction.openFile", status);
		return;
	}
	try {
		getWorkbenchPage().openSystemEditor(file);
	} catch (PartInitException e) {
		DialogUtil.openError(
			getWorkbenchPage().getWorkbenchWindow().getShell(),
			"Problems Opening System Editor",
			e.getMessage(),
			e);
	}
}
/* (non-Javadoc)
 * Method declared on IAction.
 */
public void run() {
	Iterator enum = getSelectedResources().iterator();
	while (enum.hasNext()) {
		IResource resource = (IResource) enum.next();
		if (resource instanceof IFile)
			openFile((IFile) resource);
	}
}
/**
 * The <code>OpenSystemEditorAction</code> implementation of this
 * <code>SelectionListenerAction</code> method enables the action only
 * if the selection contains just file resources.
 */
protected boolean updateSelection(IStructuredSelection selection) {
	return super.updateSelection(selection) && selectionIsOfType(IResource.FILE);
}
}
