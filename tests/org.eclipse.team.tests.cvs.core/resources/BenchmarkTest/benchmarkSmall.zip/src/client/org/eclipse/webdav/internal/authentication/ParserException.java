package org.eclipse.webdav.internal.authentication;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

/**
 * A <code>ParserException</code> is thrown by the <code>Parser</code>
 * when there is a problem parsing a <code>String</code>.
 *
 * @see Parser
 */
public class ParserException extends Exception {
	/**
	 * Creates a new <code>ParserException</code>.
	 */
	public ParserException() {
		super();
	}
	/**
	 * Creates a new <code>ParserException</code> with the given message.
	 *
	 * @param message
	 */
	public ParserException(String message) {
		super(message);
	}
}