package org.eclipse.webdav.client;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.eclipse.webdav.IContext;
import org.eclipse.webdav.ILocator;
import org.eclipse.webdav.IResponse;
import org.eclipse.webdav.http.client.HttpClient;
import org.eclipse.webdav.http.client.Request;
import org.eclipse.webdav.internal.kernel.utils.Assert;
import org.eclipse.webdav.internal.utils.URLEncoder;
import org.w3c.dom.Document;

/**
 * The <code>ServerProxy</code> class implements the <code>Server</code>
 * interface and represents a client's local proxy to a remote server.
 * This object is used to talk with the server.
 * <p>
 * <b>Note:</b> This class/interface is part of an interim API that is still under 
 * development and expected to change significantly before reaching stability. 
 * It is being made available at this early stage to solicit feedback from pioneering 
 * adopters on the understanding that any code that uses this API will almost 
 * certainly be broken (repeatedly) as the API evolves.
 * </p>
 *
 * @see Server
 */
public class RemoteDAVClient extends DAVClient {

	protected HttpClient httpClient = null;

	/**
	 * Creates a new remote DAV client from a clone of the given remote
	 * DAV client.
	 *
	 * @param davClient the DAV client to clone
	 */
	public RemoteDAVClient(RemoteDAVClient davClient) {
		super(davClient);
	}

	/**
	 * Creates a new remote DAV client.
	 *
	 * @param webDAVFactory
	 */
	public RemoteDAVClient(WebDAVFactory webDAVFactory, HttpClient httpClient) {
		super(webDAVFactory);
		this.httpClient = httpClient;
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#baselineControl(Locator, Context, Document);
	 */
	public IResponse baselineControl(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {

		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "BASELINE-CONTROL");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#bind(Locator, Locator, Context);
	 */
	public IResponse bind(
		ILocator source,
		ILocator destination,
		IContext userContext)
		throws IOException {
		Assert.isNotNull(source);
		Assert.isNotNull(destination);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, source);
		context.setDestination(URLEncoder.encode(destination.getResourceURL()));
		Request request = newRequest(source, context, "BIND");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#checkin(Locator, Context, Document);
	 */
	public IResponse checkin(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "CHECKIN");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#checkout(Locator, Context);
	 */
	public IResponse checkout(ILocator locator, IContext userContext, Document body)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, body, "CHECKOUT");

		return httpClient.invoke(request);
	}

	/**
	 * @see Object#clone
	 */
	protected Object clone() {
		return new RemoteDAVClient(this);
	}

	/**
	 * Close down the client for futire API calls.  Once a client has been clsed then callers
	 * should not expect further API cals to be sucessful.
	 */
	public void close() {
		httpClient.close();
		super.close();
	}
	
	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#copy(Locator, Locator, Context, Document);
	 */
	public IResponse copy(
		ILocator source,
		ILocator destination,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(source);
		Assert.isNotNull(destination);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, source);
		context.setDestination(URLEncoder.encode(destination.getResourceURL()));
		Request request = newRequest(source, context, document, "COPY");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#delete(Locator, Context);
	 */
	public IResponse delete(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "DELETE");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#get(Locator, Context);
	 */
	public IResponse get(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "GET");

		return httpClient.invoke(request);
	}

	/**
	 * Returns this DAV clients HTTP client.
	 */
	public HttpClient getHttpClient() {
		return httpClient;
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#head(Locator, Context);
	 */
	public IResponse head(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "HEAD");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#label(Locator, Context, Document);
	 */
	public IResponse label(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);
		Assert.isNotNull(document);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "LABEL");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#lock(Locator, Context, Document);
	 */
	public IResponse lock(ILocator locator, IContext userContext, Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "LOCK");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#merge(Locator, Context, Document);
	 */
	public IResponse merge(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);
		Assert.isNotNull(document);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "MERGE");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#mkactivity(Locator, Context, Document);
	 */
	public IResponse mkactivity(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "MKACTIVITY");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#mkcol(Locator, Context, Document);
	 */
	public IResponse mkcol(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "MKCOL");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#mkworkspace(Locator, Context, Document);
	 */
	public IResponse mkworkspace(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "MKWORKSPACE");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#move(Locator, Locator, Context, Document);
	 */
	public IResponse move(
		ILocator source,
		ILocator destination,
		IContext userContext,
		Document document)
		throws IOException {

		Assert.isNotNull(source);
		Assert.isNotNull(destination);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, source);
		context.setDestination(URLEncoder.encode(destination.getResourceURL()));
		Request request = newRequest(source, context, document, "MOVE");

		return httpClient.invoke(request);
	}

	private Request newRequest(
		ILocator locator,
		IContext context,
		InputStream is,
		String methodName)
		throws IOException {
		return new Request(
			methodName,
			URLEncoder.encode(new URL(locator.getResourceURL())),
			context,
			is);
	}

	private Request newRequest(
		ILocator locator,
		IContext context,
		String methodName)
		throws IOException {

		return new Request(
			methodName,
			URLEncoder.encode(new URL(locator.getResourceURL())),
			context);
	}

	private Request newRequest(
		ILocator locator,
		IContext context,
		Document document,
		String methodName)
		throws IOException {
		context.setContentType("text/xml; charset=\"UTF8\"");

		if (document == null) {
			return new Request(
				methodName,
				URLEncoder.encode(new URL(locator.getResourceURL())),
				context);
		}

		RequestBodyWriter writer = new RequestBodyWriter(document, "UTF8");

		return new Request(
			methodName,
			URLEncoder.encode(new URL(locator.getResourceURL())),
			context,
			writer);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#options(Locator, Context);
	 */
	public IResponse options(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "OPTIONS");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#post(Locator, Context, InputStream);
	 */
	public IResponse post(ILocator locator, IContext userContext, InputStream is)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);
		Assert.isNotNull(is);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, is, "POST");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#propfind(Locator, Context, Document);
	 */
	public IResponse propfind(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "PROPFIND");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#proppatch(Locator, Context, Document);
	 */
	public IResponse proppatch(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);
		Assert.isNotNull(document);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "PROPPATCH");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#put(Locator, Context, InputStream);
	 */
	public IResponse put(ILocator locator, IContext userContext, InputStream is)
		throws IOException {

		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);
		Assert.isNotNull(is);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, is, "PUT");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#report(Locator, Context, Document);
	 */
	public IResponse report(
		ILocator locator,
		IContext userContext,
		Document document)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);
		Assert.isNotNull(document);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, document, "REPORT");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#trace(Locator, Context, InputStream);
	 */
	public IResponse trace(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "TRACE");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#uncheckout(Locator, Context);
	 */
	public IResponse uncheckout(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "UNCHECKOUT");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#unlock(Locator, Context);
	 */
	public IResponse unlock(ILocator locator, IContext userContext)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, "UNLOCK");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#update(Locator, Context, Document);
	 */
	public IResponse update(ILocator locator, IContext userContext, Document body)
		throws IOException {
		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, body, "UPDATE");

		return httpClient.invoke(request);
	}

	/**
	 * Part of the <code>Server</code> interface.
	 * @see Server#versionControl(Locator, Context, Document);
	 */
	public IResponse versionControl(
		ILocator locator,
		IContext userContext,
		Document body)
		throws IOException {

		Assert.isNotNull(locator);
		Assert.isNotNull(userContext);

		IContext context = newContext(userContext, locator);
		Request request = newRequest(locator, context, body, "VERSION-CONTROL");

		return httpClient.invoke(request);
	}
}