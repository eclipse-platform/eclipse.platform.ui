package org.eclipse.webdav.dom;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

import java.util.*;
import org.eclipse.webdav.Policy;import org.w3c.dom.*;

/**
 * An element editor for the WebDAV lockdiscovery element. See RFC2518
 * section 13.8 for the element's definition.
 * <p>
 * <b>Note:</b> This class/interface is part of an interim API that is still under 
 * development and expected to change significantly before reaching stability. 
 * It is being made available at this early stage to solicit feedback from pioneering 
 * adopters on the understanding that any code that uses this API will almost 
 * certainly be broken (repeatedly) as the API evolves.
 * </p>
 *
 * @see ActiveLock
 */
public class LockDiscovery extends Property {
	/**
	 * An ordered collection of the element names of the lockdiscovery
	 * element's children.
	 */
	protected static final String[] childNames = new String[] {"activelock"};
/**
 * Creates a new editor on the given WebDAV lockdiscovery element. The
 * element is assumed to be well formed.
 *
 * @param root a lockdiscovery element
 * @throws        MalformedElementException if there is reason to
 *                believe that the element is not well formed
 */
public LockDiscovery(Element root) throws MalformedElementException {

	super(root, "lockdiscovery");
}
/**
 * Creates and adds a new activelock on this lockdiscovery and returns
 * an editor on it.
 *
 * @return an editor on an activelock element
 */
public ActiveLock addActiveLock() {

	Element activelock = addChild(root, "activelock", childNames, false);
	Element locktype = appendChild(activelock, "locktype");
	appendChild(locktype, "write");

	ActiveLock result = null;
	try {
		result = new ActiveLock(activelock);
	} catch (MalformedElementException e) {
		Assert.isTrue(false, Policy.bind("assert.internalError"));
	}

	return result;
}
/**
 * Returns an <code>Enumeration</code> over this lockdiscovery's
 * <code>ActiveLock</code>s.
 *
 * @return an <code>Enumeration</code> of <code>ActiveLock</code>s
 * @throws MalformedElementException if there is reason to believe that
 *         this editor's underlying element is not well formed
 */
public Enumeration getActiveLocks() throws MalformedElementException {

	final Node firstActiveLock = getFirstChild(root, "activelock");

	Enumeration e = new Enumeration() {
		Node currentActiveLock = firstActiveLock;

		public boolean hasMoreElements() {

			return currentActiveLock != null;
		}

		public Object nextElement() {

			if (!hasMoreElements())
				throw new NoSuchElementException();

			ActiveLock result = null;
			try {
				result = new ActiveLock((Element) currentActiveLock);
			} catch (MalformedElementException ex) {
				Assert.isTrue(false, Policy.bind("assert.internalError"));
			}
			currentActiveLock = getTwin((Element) currentActiveLock, true);

			return result;
		}
	};

	return e;
}
}
