package org.eclipse.webdav.internal.kernel;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

public class DAVException extends Exception {
	/**
	 * DAV4JException default constructor.
	 */
	public DAVException() {
		super();
	}


	public DAVException(String s) {
		super(s);
	}

}