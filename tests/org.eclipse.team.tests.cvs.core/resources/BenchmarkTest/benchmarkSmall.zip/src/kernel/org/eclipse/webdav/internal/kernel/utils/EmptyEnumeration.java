package org.eclipse.webdav.internal.kernel.utils;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

import java.util.NoSuchElementException;

public class EmptyEnumeration extends EnumerationFilter {
public EmptyEnumeration() {
	super();
}
public boolean hasMoreElements() {

	return false;
}
public Object nextElement() {
	
	throw new NoSuchElementException();
}
}
