package org.eclipse.webdav.internal.kernel.utils;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

import java.util.Enumeration;

public abstract class EnumerationFilter implements Enumeration {
public EnumerationFilter() {
	
	super();
}
public abstract boolean hasMoreElements();
public abstract Object nextElement();
}
