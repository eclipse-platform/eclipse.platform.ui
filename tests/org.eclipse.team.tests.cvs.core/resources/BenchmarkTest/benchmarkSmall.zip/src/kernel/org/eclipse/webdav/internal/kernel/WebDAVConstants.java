package org.eclipse.webdav.internal.kernel;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

public interface WebDAVConstants {
	
 	// Namespace URI for all WebDAV elements.
	String DAV_URI = "DAV:";
}
