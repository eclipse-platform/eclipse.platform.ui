package org.eclipse.webdav.internal.kernel.utils;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

import java.util.Enumeration;

public abstract class EnumerationConverter extends EnumerationFilter {

	protected Enumeration sourceEnum;
public EnumerationConverter(Enumeration sourceEnum) {
	
	super();

	this.sourceEnum = sourceEnum;
}
public boolean hasMoreElements() {
	
	return sourceEnum.hasMoreElements();
}
// Subclasses should override ths method to convert the
// source enum objects to the new types.
public abstract Object nextElement();
}
