package org.eclipse.webdav.internal.kernel;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

import org.apache.xerces.dom.DocumentImpl;
import org.w3c.dom.Document;

public class DocumentFactory implements IDocumentFactory {

	public Document newDocument() {
		return new DocumentImpl();
	}
}