package org.eclipse.webdav.internal.kernel;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */

public class SystemException extends DAVException {

	protected Exception wrappedException;

	/**
	 * SystemException default constructor.
	 */
	public SystemException() {
		super();
	}

	public SystemException(Exception e) {
		super();
		wrappedException = e;
	}

	public SystemException(String s) {
		super(s);
	}

	public Exception getWrappedException() {
		return wrappedException;
	}

	public void setWrappedException(Exception e) {
		wrappedException = e;
	}
}