package org.eclipse.swt.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class OleParameterDescription {
	public String name;
	public short flags;
	public short type;
}
