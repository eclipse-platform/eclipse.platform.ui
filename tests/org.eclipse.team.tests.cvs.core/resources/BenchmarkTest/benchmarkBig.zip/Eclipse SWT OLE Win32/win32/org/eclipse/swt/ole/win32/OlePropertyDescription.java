package org.eclipse.swt.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class OlePropertyDescription {
	public int id;
	public String name;
	public int type;
	public int flags;
	public int kind;
	public String description;
	public String helpFile;
}
