package org.eclipse.swt.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

/**
 */
public interface OleListener
{
/**
 *
 */
public void handleEvent(OleEvent event);
}
