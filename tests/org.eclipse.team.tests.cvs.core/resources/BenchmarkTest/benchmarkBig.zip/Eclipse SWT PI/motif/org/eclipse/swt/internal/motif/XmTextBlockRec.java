package org.eclipse.swt.internal.motif;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
 
public class XmTextBlockRec {
	public int ptr;			// 0
	public int length;		// 4
	public int format;		// 8
	public static final int sizeof = 12;
}
