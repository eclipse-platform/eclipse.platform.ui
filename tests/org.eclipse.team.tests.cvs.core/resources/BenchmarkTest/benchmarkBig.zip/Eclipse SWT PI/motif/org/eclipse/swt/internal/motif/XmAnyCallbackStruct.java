package org.eclipse.swt.internal.motif;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
 
public class XmAnyCallbackStruct {
	public int reason;		// 0
	public int event;		// 4
	public static final int sizeof = 8;
}
