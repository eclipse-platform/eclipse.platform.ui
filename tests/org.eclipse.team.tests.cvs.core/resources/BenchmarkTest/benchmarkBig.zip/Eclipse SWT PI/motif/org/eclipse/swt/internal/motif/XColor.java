package org.eclipse.swt.internal.motif;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
 
public class XColor {
	public int pixel;
	public short red, green, blue;
	public byte flags;
	public byte pad;
	public static final int sizeof = 12;
}
