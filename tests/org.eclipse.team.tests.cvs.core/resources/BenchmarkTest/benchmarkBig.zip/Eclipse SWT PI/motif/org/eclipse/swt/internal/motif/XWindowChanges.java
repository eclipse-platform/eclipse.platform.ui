package org.eclipse.swt.internal.motif;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
 
public class XWindowChanges {
	public int x, y;
	public int width, height;
	public int border_width;
	public int sibling;
	public int stack_mode;
	public static final int sizeof = 28;
}
