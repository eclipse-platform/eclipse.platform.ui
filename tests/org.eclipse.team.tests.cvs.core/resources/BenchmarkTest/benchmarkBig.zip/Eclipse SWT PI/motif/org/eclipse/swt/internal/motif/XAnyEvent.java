package org.eclipse.swt.internal.motif;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
 
public class XAnyEvent extends XEvent {
	public int pad0, pad1, pad2, pad3, pad4, pad5, pad6, pad7, pad8, pad9;
	public int pad10, pad11, pad12, pad13, pad14, pad15, pad16, pad17, pad18;
}
