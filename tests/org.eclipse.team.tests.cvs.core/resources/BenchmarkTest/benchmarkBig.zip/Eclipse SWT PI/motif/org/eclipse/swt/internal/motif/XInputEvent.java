package org.eclipse.swt.internal.motif;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
 
public abstract class XInputEvent extends XWindowEvent {
	public int state;	/* key or button mask */
}
