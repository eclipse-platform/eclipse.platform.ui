package org.eclipse.swt.internal.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public final class LICINFO
{
	public int cbLicInfo;
	public int fRuntimeKeyAvail;
	public int fLicVerified;
	
	public static final int sizeof = 12;
}
