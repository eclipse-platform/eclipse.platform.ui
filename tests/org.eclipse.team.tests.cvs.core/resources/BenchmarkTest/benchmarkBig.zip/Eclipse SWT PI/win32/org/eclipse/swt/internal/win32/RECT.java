package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class RECT {
	public int left;
	public int top;
	public int right;
	public int bottom;
	public static final int sizeof = 16;
}
