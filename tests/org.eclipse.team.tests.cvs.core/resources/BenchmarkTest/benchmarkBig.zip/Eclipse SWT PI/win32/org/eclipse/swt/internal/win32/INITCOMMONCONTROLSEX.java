package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class INITCOMMONCONTROLSEX {
	public int dwSize; 
	public int dwICC;
	public static final int sizeof = 8;
}
