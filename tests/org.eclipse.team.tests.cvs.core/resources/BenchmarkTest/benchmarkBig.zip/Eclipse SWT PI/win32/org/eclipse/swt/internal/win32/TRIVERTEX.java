package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class TRIVERTEX {
	public int x;
	public int y;
	public short Red;
	public short Green;
	public short Blue;
	public short Alpha;
	public static final int sizeof = 16;
}

