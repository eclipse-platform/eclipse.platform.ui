package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class COMPOSITIONFORM {
	public int dwStyle;       
//	POINT ptCurrentPos;
	public int x, y;
//	RECT rcArea;  
	public int left, top, right, bottom;
	public static final int sizeof = 28;
}
