package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class GCP_RESULTS {
	public int lStructSize;
	public int lpOutString;
	public int lpOrder;
	public int lpDx;
	public int lpCaretPos;
	public int lpClass;
	public int lpGlyphs;
	public int nGlyphs;
	public int nMaxFit;
	public static final int sizeof = 36;
}

