package org.eclipse.swt.internal.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public final class STGMEDIUM
{
	public int tymed;
	public int unionField;
	public int pUnkForRelease;
	
	public static final int sizeof = 12;
}
