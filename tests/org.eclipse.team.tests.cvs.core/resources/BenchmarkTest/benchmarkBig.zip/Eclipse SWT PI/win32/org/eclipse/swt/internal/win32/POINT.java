package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class POINT {
	public int x;
	public int y;
	public static final int sizeof = 8;
}
