package org.eclipse.swt.internal.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public final class FORMATETC
{
	public int cfFormat;
	public int ptd;
	public int dwAspect;
	public int lindex;
	public int tymed;
	
	public static final int sizeof = 20;
}
