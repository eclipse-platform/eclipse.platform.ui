package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class LOGPEN {
	public int lopnStyle;
//	POINT    lopnWidth; 
	public int x;
	public int y;
	public int lopnColor;
	public static final int sizeof = 16;
}
