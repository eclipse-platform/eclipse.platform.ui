package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class HDITEM {
	public int mask;
	public int cxy;
	public int pszText;
	public int hbm;
	public int cchTextMax;
	public int fmt;
	public int lParam; 
	public int iImage;
	public int iOrder;
	public static int sizeof = 36;
}
