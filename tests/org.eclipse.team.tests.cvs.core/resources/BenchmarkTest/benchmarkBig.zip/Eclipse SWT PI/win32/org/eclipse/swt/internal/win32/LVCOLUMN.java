package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class LVCOLUMN {
	public int mask;
	public int fmt;
	public int cx;
	public int pszText;
	public int cchTextMax;
	public int iSubItem;
	public int iImage;
	public int iOrder;
	public static final int sizeof = 24;
}
