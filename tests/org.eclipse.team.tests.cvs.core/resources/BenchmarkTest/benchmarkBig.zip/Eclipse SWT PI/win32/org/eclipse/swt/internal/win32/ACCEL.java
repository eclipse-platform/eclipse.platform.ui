package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class ACCEL {
	public byte fVirt;
	public short key;
	public short cmd;
	public static final int sizeof = OS.IsWinCE ? 8 : 6;
}
