package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class WINDOWPOS {
	public int hwnd;                     
	public int hwndInsertAfter;
	public int x;                        
	public int y;
	public int cx;                       
	public int cy;
	public int flags;  
	public static final int sizeof = 28;
}
