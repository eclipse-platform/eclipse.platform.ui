package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class ICONINFO {
	public boolean fIcon;
	public int xHotspot; 
	public int yHotspot;
	public int hbmMask;
	public int hbmColor;
	public static final int sizeof = 20;
}
