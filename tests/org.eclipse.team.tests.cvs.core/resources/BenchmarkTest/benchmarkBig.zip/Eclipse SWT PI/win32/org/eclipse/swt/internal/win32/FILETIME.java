package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class FILETIME {
	public int dwLowDateTime;
	public int dwHighDateTime;
	static final public int sizeof = 8;
}

