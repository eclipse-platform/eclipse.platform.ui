package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class TVHITTESTINFO {
//	POINT pt;
	public int x;
	public int y;
	public int flags;
	public int hItem;
	public static int sizeof = 16;
}
