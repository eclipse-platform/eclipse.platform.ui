package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class NMHEADER extends NMHDR {
	public int iItem; 
	public int iButton; 
	public int pitem; 
	public static int sizeof = 24;
}
