package org.eclipse.swt.internal.ole.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class IEnumFORMATETC extends IEnum {
public IEnumFORMATETC(int address) {
	super(address);
}
}
