package org.eclipse.swt.internal.win32;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */
public class MENUINFO {
	public int cbSize;
	public int fMask;
	public int dwStyle;
	public int cyMax;
	public int hbrBack;
	public int dwContextHelpID;
	public int dwMenuData;
	public static final int sizeof = 28;
}
