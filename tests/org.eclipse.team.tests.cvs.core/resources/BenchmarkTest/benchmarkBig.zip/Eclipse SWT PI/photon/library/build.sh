#!/bin/sh

# (c) Copyright IBM Corp., 2000, 2001
# All Rights Reserved.

export IVE_HOME=~/ive/bin

make -f make_photon.mak $1 $2 $3 $4