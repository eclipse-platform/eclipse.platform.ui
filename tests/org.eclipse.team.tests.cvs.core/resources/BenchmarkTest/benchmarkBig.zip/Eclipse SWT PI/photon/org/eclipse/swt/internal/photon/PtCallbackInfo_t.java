package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PtCallbackInfo_t {
	public int reason;
	public int reason_subtype;
	public int event;
	public int cbdata;
	public static final int sizeof = 16;
}
