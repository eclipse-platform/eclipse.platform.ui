package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PgMap_t {
	
	public short dim_w;
	public short dim_h;
	public short bpl;
	public short bpp;
	public int map;
	public static final int sizeof = 12;
}
