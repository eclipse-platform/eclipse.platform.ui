package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PtScrollbarCallback_t {
	public int action;
	public int position;
	public static final int sizeof = 8;
}
