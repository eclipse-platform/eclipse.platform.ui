package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PhClipHeader {

	public byte type_0;
	public byte type_1;
	public byte type_2;
	public byte type_3;
	public byte type_4;
	public byte type_5;
	public byte type_6;
	public byte type_7;
	public short length;
	public short zero;
	public int data;
	
	public static final int sizeof = 16;

}

