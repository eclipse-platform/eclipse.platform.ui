package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PtTextCallback_t {
	public int start_pos;
	public int end_pos;
	public int cur_insert;
	public int new_insert;
	public int length;
	public short reserved;
	public int text;
	public int doit;
	public static final int sizeof = 30;
}
