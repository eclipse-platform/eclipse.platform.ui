package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PhRect_t {
	public short ul_x;
	public short ul_y;
	public short lr_x;
	public short lr_y;
	public static final int sizeof = 8;
}
