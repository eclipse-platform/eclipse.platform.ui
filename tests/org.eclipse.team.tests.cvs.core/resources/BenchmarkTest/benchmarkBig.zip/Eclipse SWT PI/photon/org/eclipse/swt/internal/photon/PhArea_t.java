package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PhArea_t {
	public short pos_x;
	public short pos_y;
	public short size_w;
	public short size_h;
	public static final int sizeof = 8;
}
