package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PhPoint_t {
	public short x;
	public short y;
	public static final int sizeof = 4;
}
