package org.eclipse.swt.internal.photon;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class PhDim_t {
	public short w;
	public short h;
	public static final int sizeof = 4;
}
