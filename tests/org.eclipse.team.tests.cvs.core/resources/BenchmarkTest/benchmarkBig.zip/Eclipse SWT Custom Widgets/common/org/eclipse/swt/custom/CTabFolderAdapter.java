package org.eclipse.swt.custom;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class CTabFolderAdapter implements CTabFolderListener {
	public void itemClosed(CTabFolderEvent event){};
}
