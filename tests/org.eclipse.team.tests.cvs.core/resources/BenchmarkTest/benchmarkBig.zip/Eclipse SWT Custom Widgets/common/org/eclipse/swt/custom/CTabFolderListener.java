package org.eclipse.swt.custom;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public interface CTabFolderListener {
	public void itemClosed(CTabFolderEvent event);
}
