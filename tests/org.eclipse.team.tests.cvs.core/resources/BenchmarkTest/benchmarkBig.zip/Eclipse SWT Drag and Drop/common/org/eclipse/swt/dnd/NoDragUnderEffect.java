package org.eclipse.swt.dnd;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

import org.eclipse.swt.widgets.*;

class NoDragUnderEffect extends DragUnderEffect {

NoDragUnderEffect(Control control) {}
void show(int effect, int x, int y){}
}
