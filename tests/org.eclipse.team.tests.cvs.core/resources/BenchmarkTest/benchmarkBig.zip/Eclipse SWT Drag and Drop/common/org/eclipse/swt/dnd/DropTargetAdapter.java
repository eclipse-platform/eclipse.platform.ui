package org.eclipse.swt.dnd;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class DropTargetAdapter implements DropTargetListener {
	
public void dragEnter(DropTargetEvent event){};
public void dragLeave(DropTargetEvent event){};
public void dragOperationChanged(DropTargetEvent event){};
public void dragOver(DropTargetEvent event){};
public void drop(DropTargetEvent event){};
public void dropAccept(DropTargetEvent event){};


}
