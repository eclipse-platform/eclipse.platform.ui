package org.eclipse.swt.dnd;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

public class DragSourceAdapter implements DragSourceListener {
	public void dragStart(DragSourceEvent event){};
	public void dragFinished(DragSourceEvent event){};
	public void dragSetData(DragSourceEvent event){};
}
