package org.eclipse.swt.dnd;

/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved
 */

import org.eclipse.swt.widgets.*;

abstract class DragUnderEffect {
	
abstract void show(int effect, int x, int y);

}
