This test covers symbolic links that span up a new tree
outside the project. Such new resources must not ever
be suppressed. Particularly, link_to_l1 which points
to a higher level than l4, must not be suppressed.

a/link_to_l4 -> ../../not_a_proj/l1/l2/l3/l4
b/link_to_l1 -> ../../not_a_proj/l1
