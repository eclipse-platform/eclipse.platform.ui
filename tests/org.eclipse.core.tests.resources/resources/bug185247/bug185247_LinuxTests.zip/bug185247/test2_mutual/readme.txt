This test covers mutually recursive symbolic links:

a/linkb -> ../b
b/linka -> ../a

Both inside and outside a project scope:

outside_mutual -> ../outside_mutual
outside_mutual/a/linkb -> ../b
outside_mutual/b/linka --> ../a