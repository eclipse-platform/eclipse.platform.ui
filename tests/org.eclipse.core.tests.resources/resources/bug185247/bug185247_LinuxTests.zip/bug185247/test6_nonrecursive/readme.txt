This test checks for complex structures of symbolic links
that are actually not recursive:

a1/a2/linkb -> ../../b
b/linkc -> ../c
c/cfile.txt

The intention of this is, that linkb repeats the structure
below b in the resource tree (creating duplicate resources).

The problem with this setup and the current implementation is,
that because the UnifiedTree does a breadth-first-search,
it finds b/linkc first and thus thinks that any prefix
of b/linkc is bound to be a recursive symbolic link. Therefore,
the symbolic linkb (which points to b) is IGNORED.

linkb is thus not added, this is INCORRECT BEHAVIOR, but for
now we accept it. See bug 105554 for details.
