This test covers the trivial symbolic link cases:
c1/myself -> .
c2/parent -> ..
c3/grandparent -> ../..

None of these should be visible.