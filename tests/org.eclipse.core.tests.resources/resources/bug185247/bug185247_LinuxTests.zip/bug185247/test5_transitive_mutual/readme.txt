This test checks for mutually recursive symbolic links
when a chain of symbolic links needs to be followed 
in a transitive manner:

a/linkb2 -> ../linkholder/b2 -> b1 -> ../b
b/linka2 -> ../linkholder/a2 -> a1 -> ../a

At the same time, there is 

a/linkc2 -> ../linkholder/c2 -> c1 -> ../c

which is not recursive, in order to check that linkc2
is always shown.
