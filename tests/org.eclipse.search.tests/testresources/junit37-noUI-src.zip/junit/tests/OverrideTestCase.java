package junit.tests;

/**
 * Test class used in SuiteTest
 */
public class OverrideTestCase extends OneTestCase {
	public OverrideTestCase(String name) {
		super(name);
	}
	public void testCase() {
	}
}